/**
 * Bundled image assets. Designs store short logical paths (e.g. "/images/coast.jpg")
 * so saved documents stay small; this map resolves them to the bundled (inlined) URLs
 * at render time.
 *
 * The SVGs live in src/assets/images and are inlined into the build, so the app keeps
 * working even when only dist/index.html is served.
 */
const files = import.meta.glob("../assets/images/**/*.svg", { eager: true, query: "?url", import: "default" }) as Record<string, string>;

/** "../assets/images/photos/lake.svg" -> "/images/photos/lake.jpg" (the logical path stored in designs). */
const assetMap: Record<string, string> = {};
for (const [path, url] of Object.entries(files)) {
  const logical = path.replace("../assets", "").replace(/\.svg$/, ".jpg");
  assetMap[logical] = url;
}

/** Resolves a stored image path (or data URL) to something the browser can load. */
export function resolveAsset(src?: string | null): string {
  if (!src) return "";
  return assetMap[src] ?? src;
}
