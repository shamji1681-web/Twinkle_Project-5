import { useEffect, useId, useRef, useState, type CSSProperties } from "react";

interface NumericProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  disabled?: boolean;
  className?: string;
  onCommit: (value: number) => void;
}

/** Drafts can be empty/negative while typing; only valid, clamped values reach the document. */
export function NumericValue({ label, value, min, max, step = 1, disabled, className = "", onCommit }: NumericProps) {
  const precision = Math.min(6, Math.max(0, (String(step).split(".")[1] || "").length));
  const display = (n: number) => String(Number(n.toFixed(Math.max(precision, 2))));
  const [draft, setDraft] = useState(() => display(value));
  const focused = useRef(false), cancelled = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(display(value)); }, [value, step]); // eslint-disable-line react-hooks/exhaustive-deps
  function commit() {
    focused.current = false;
    const n = Number(draft);
    if (cancelled.current || !draft.trim() || !Number.isFinite(n)) { setDraft(display(value)); return; }
    const rounded = Math.round((n - min) / step) * step + min;
    const next = Number(Math.min(max, Math.max(min, rounded)).toFixed(6));
    setDraft(display(next));
    if (Math.abs(next - value) > .000001) onCommit(next);
  }
  return <input type="number" className={`manual-range-value ${className}`} aria-label={label} value={draft} min={min} max={max} step={step} disabled={disabled} inputMode="decimal" onFocus={() => { focused.current = true; cancelled.current = false; }} onChange={e => setDraft(e.target.value)} onBlur={commit} onKeyDown={e => {
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); e.currentTarget.blur(); }
    if (e.key === "Escape") { e.preventDefault(); cancelled.current = true; e.currentTarget.blur(); }
  }} />;
}

interface Props {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  numberLabel?: string;
  onChange: (value: number) => void;
  onCommit?: (value: number) => void;
  disabled?: boolean;
  compact?: boolean;
  hideLabel?: boolean;
  className?: string;
  sliderClassName?: string;
  sliderStyle?: CSSProperties;
}

/** Every range gets the same manual input, bounds, precision and keyboard behaviour. */
export default function RangeControl({ label, value, min, max, step = 1, unit, numberLabel, onChange, onCommit, disabled, compact = false, hideLabel = false, className = "", sliderClassName = "", sliderStyle }: Props) {
  const id = useId();
  const current = Number.isFinite(value) ? value : min;
  return <div className={`range-control ${compact ? "range-compact" : ""} ${className}`} data-range-control>
    {!hideLabel && <label className="range-control-label" htmlFor={id}>{label}</label>}
    <div className="range-control-inputs">
      <input id={id} className={sliderClassName} style={sliderStyle} type="range" aria-label={label} min={min} max={max} step={step} value={current} disabled={disabled} onChange={e => onChange(Number(e.target.value))} onPointerUp={e => onCommit?.(Number(e.currentTarget.value))} onKeyUp={e => { if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown"].includes(e.key)) onCommit?.(Number(e.currentTarget.value)); }} />
      <div className="range-manual"><NumericValue label={numberLabel || `${label} value`} value={current} min={min} max={max} step={step} disabled={disabled} onCommit={v => { onChange(v); onCommit?.(v); }} />{unit && <span>{unit}</span>}</div>
    </div>
  </div>;
}
