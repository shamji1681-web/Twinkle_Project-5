export type LayerType = "text" | "rect" | "ellipse" | "image" | "star" | "flower" | "line" | "icon" | "shape" | "stroke" | "table" | "draw" | "pattern";

import { isQRSettings, type QRSettings } from "@/lib/qr";
import { isOpacityFade, type OpacityFade } from "@/lib/opacity-fade";
import { isTableAppearance, type BorderLineStyle, type TableBorder } from "@/lib/table";
import { isGradientFill, type GradientFill } from "@/lib/gradient";
import type { CellTextStyle } from "@/lib/cell-typography";
export { gradientStopsOf, gradientCss, hexWithAlpha } from "@/lib/gradient";
export type { GradientFill, GradientStop } from "@/lib/gradient";

export interface DesignLayer {
  id: string;
  type: LayerType;
  x: number;
  y: number;
  width: number;
  height: number;
  fill: string;
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: number;
  italic?: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  letterSpacing?: number;
  lineHeight?: number;
  /** CorelDRAW word spacing scale (default 1 = 100%, 0.5 = 50%, 2 = 200%). */
  wordSpacing?: number;
  /** CorelDRAW first line indent / hanging indent in px. */
  firstLineIndent?: number;
  /** CorelDRAW paragraph spacing before/after in px. */
  paraSpacing?: number;
  align?: "left" | "center" | "right" | "justify" | "justify-all";
  /** Bullet / list styling for text: every paragraph gets a marker. */
  listStyle?: "none" | "bullet" | "number" | "dash" | "arrow" | "check" | "star" | "diamond";
  /** Word bullet symbol variant: solid disc, hollow circle, square, check, arrow, diamond, star, dash. */
  listBulletVariant?: "bullet" | "circle" | "square" | "check" | "arrow" | "diamond" | "star" | "dash";
  /** Word numbering schema: 1. / 1) / a. / a) / A. / i. / I. */
  listNumberFormat?: "number" | "number-paren" | "alpha-lower" | "alpha-lower-paren" | "alpha-upper" | "roman-lower" | "roman-upper";
  /** Custom starting number for numbered lists (default 1). */
  listStart?: number;
  /** Per-paragraph list level (0–8): Word's Tab demotes and Shift+Tab promotes. */
  paraLevels?: number[];
  /** Enlarges the first letter across the first lines, magazine style. */
  dropCap?: boolean;
  /** Word's "Lines to drop": how many rows the opening letter spans. */
  dropCapLines?: number;
  /** Word's "In margin": the letter sits outside the text column. */
  dropCapMargin?: boolean;
  /** Word's "Distance from text" between the letter and the paragraph. */
  dropCapGap?: number;
  /** Custom font family specifically for the drop cap glyph. */
  dropCapFont?: string;
  /** Custom color/fill specifically for the drop cap glyph. */
  dropCapFill?: string;
  /** Sub / superscript size as a percentage of the parent run (Word: 65). */
  scriptSize?: number;
  /** Sub / superscript baseline offset as a percentage (Word: 33 raised / 25 lowered). */
  scriptShift?: number;
  /** Whole-box baseline shift for sub / superscript text. */
  script?: "sub" | "super";
  /** Inline sub/superscript spans over selected words. Offsets are UTF-16 units (match textarea selection). */
  scriptRanges?: Array<{ start: number; end: number; kind: "sub" | "super" }>;
  /** Group marker for Ctrl+G grouping; grouped layers move and paste as one. */
  groupId?: string;
  /** Locked inside a group: group tunnel edits only (not selectable directly). */
  groupLocked?: boolean;
  rotation?: number;
  opacity?: number;
  /** Spatial opacity mask: one side stays visible, the other fades away. */
  opacityFade?: OpacityFade;
  src?: string;
  radius?: number;
  path?: string;
  shape?: string;
  outline?: boolean;
  strokeWidth?: number;
  variant?: string;
  rows?: number;
  cols?: number;
  cells?: string[];
  cellFill?: string;
  lineColor?: string;
  d?: string;
  drawTool?: "pencil" | "marker" | "highlighter" | "brush";
  /** Eraser dabs in layer-local coordinates: [x, y, radius, strength?]. The element itself stays intact. */
  erased?: ([number, number, number] | [number, number, number, number])[];
  naturalWidth?: number;
  naturalHeight?: number;
  pattern?: string;
  tile?: number;
  hidden?: boolean;
  locked?: boolean;
  autoFit?: boolean;
  qr?: QRSettings;
  /** Original image before background removal, so it can be restored. */
  originalSrc?: string;
  effects?: LayerEffects;
  /** Column widths / row heights as fractions that sum to 1 (tables). */
  colWidths?: number[];
  rowHeights?: number[];
  /** Grid line thickness in canvas units (tables). */
  lineWidth?: number;
  headerFill?: string;
  /** Table appearance: shared edge overrides and individual cell fills. */
  tableLineStyle?: BorderLineStyle;
  tableBorders?: Record<string, TableBorder>;
  cellFills?: Record<string, string>;
  cellGradients?: Record<string, GradientFill>;
  cellTextColors?: Record<string, string>;
  cellTextStyles?: Record<string, CellTextStyle>;
  /** Multi-stop fill that paints the element instead of a solid colour. */
  fillGradient?: GradientFill;
  /** Alpha for the solid fill colour (0–1). */
  fillAlpha?: number;
  /** Image used as a fill (image-inside-text, or a photo clipped to a shape). */
  fillImage?: string;
  /** Crop controls for image fills (1 = cover; pan is 0–1). */
  fillImageZoom?: number;
  fillImageX?: number;
  fillImageY?: number;
  /** Text-specific outline that remains visible when the inner fill is transparent. */
  textStrokeColor?: string;
  textStrokeWidth?: number;
  textFillTransparent?: boolean;
  /** Degrees of arc for curved text. 0 is straight; negative curves the other way. */
  curve?: number;
  /** Photo zoom inside its frame (1 = fill, up to 4 = close crop). */
  cropZoom?: number;
  /** Horizontal / vertical pan of a cropped photo, 0–1. */
  cropX?: number;
  cropY?: number;
  /** Clip a photo to a named mask shape. */
  mask?: string;
  /** Merged table regions, identified by their origin cell. */
  merges?: { r: number; c: number; rowspan: number; colspan: number }[];
}

export interface LayerEffects {
  shadow?: { color: string; blur: number; x: number; y: number; opacity: number };
  glow?: { color: string; blur: number; opacity: number };
  outline?: { color: string; width: number };
  blur?: number;
  brightness?: number;
  contrast?: number;
  saturation?: number;
  grayscale?: number;
  sepia?: number;
  flipX?: boolean;
  flipY?: boolean;
}

export interface DesignDocument {
  width: number;
  height: number;
  background: string;
  layers: DesignLayer[];
}

export interface DesignProject {
  id: string;
  title: string;
  category: string;
  content: DesignDocument;
  starred: boolean;
  trashed: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DesignTemplate { id: string; title: string; category: string; tag: string; pro?: boolean; content: DesignDocument }
export interface Workspace { id: string; name: string; brandName: string; colors: string[]; logo: string | null; trialStartedAt: string | null }

export const MAX_LAYERS = 150;
export const FONTS = ["Arial", "Georgia", "Verdana", "Courier New"];
const layerCount = { n: 0 };
export const newId = () => `${Date.now().toString(36)}-${(layerCount.n++).toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

const text = (value: string, x: number, y: number, width: number, fontSize: number, fill: string, extra: Partial<DesignLayer> = {}): DesignLayer => ({ id: `layer-${++layerCount.n}`, type: "text", x, y, width, height: value.split("\n").length * fontSize * 1.13, text: value, fontSize, fill, fontFamily: "Arial", fontWeight: 400, ...extra });
const shape = (type: LayerType, x: number, y: number, width: number, height: number, fill: string, extra: Partial<DesignLayer> = {}): DesignLayer => ({ id: `layer-${++layerCount.n}`, type, x, y, width, height, fill, ...extra });
const photo = (src: string, x: number, y: number, width: number, height: number, extra: Partial<DesignLayer> = {}): DesignLayer => shape("image", x, y, width, height, "transparent", { src, ...extra });

/** Creates a centred layer sized as a fraction of the canvas. */
export function centeredLayer(doc: DesignDocument, layer: Omit<DesignLayer, "id" | "x" | "y"> & { x?: number; y?: number }): DesignLayer {
  return { ...layer, id: newId(), x: layer.x ?? (doc.width - layer.width) / 2, y: layer.y ?? (doc.height - layer.height) / 2 };
}

export function makeIcon(doc: DesignDocument, path: string, filled: boolean, sizeRatio = .2, color = "#7952e9"): DesignLayer {
  const size = Math.round(Math.min(doc.width, doc.height) * sizeRatio);
  return centeredLayer(doc, { type: "icon", width: size, height: size, fill: color, path, outline: !filled });
}

export function makeShape(doc: DesignDocument, shapeKey: string, color = "#7952e9", ratio = .32, outline = false): DesignLayer {
  const size = Math.round(Math.min(doc.width, doc.height) * ratio);
  return centeredLayer(doc, { type: "shape", width: size, height: size, fill: color, shape: shapeKey, outline });
}

export function makeStroke(doc: DesignDocument, variant: string, color = "#7952e9", strokeWidth?: number): DesignLayer {
  const width = Math.round(doc.width * .6);
  const weight = strokeWidth ?? Math.max(4, Math.round(doc.width * .008));
  return centeredLayer(doc, { type: "stroke", width, height: Math.max(18, weight * 4), fill: color, variant, strokeWidth: weight });
}

export function makePhoto(doc: DesignDocument, src: string, ratio = .55): DesignLayer {
  const width = Math.round(doc.width * ratio), height = Math.round(width * .68);
  return centeredLayer(doc, { type: "image", width, height, fill: "transparent", src });
}

export function makePattern(doc: DesignDocument, pattern: string, color: string): DesignLayer {
  return { id: newId(), type: "pattern", x: 0, y: 0, width: doc.width, height: doc.height, fill: color, pattern, tile: Math.max(24, Math.round(doc.width / 18)) };
}

export function makeTable(doc: DesignDocument, rows: number, cols: number, color = "#7952e9"): DesignLayer {
  const width = Math.round(doc.width * .7), height = Math.round(Math.min(doc.height * .6, rows * width / cols * .62));
  return centeredLayer(doc, {
    type: "table", width, height, fill: color, rows, cols,
    cells: Array.from({ length: rows * cols }, (_, i) => i < cols ? ["Name", "Role", "Note", "Link"][i % 4] : ""),
    cellFill: "transparent", lineColor: color, lineWidth: 2,
    colWidths: Array.from({ length: cols }, () => 1 / cols), rowHeights: Array.from({ length: rows }, () => 1 / rows),
  });
}

export function makeText(doc: DesignDocument, style: "heading" | "subheading" | "body"): DesignLayer {
  const size = Math.round(doc.width * (style === "heading" ? .082 : style === "subheading" ? .052 : .03));
  const value = style === "heading" ? "Your big idea" : style === "subheading" ? "A little more inspiration" : "Tell your story. Make it yours.";
  const width = Math.round(doc.width * .76);
  return { id: newId(), type: "text", x: Math.round((doc.width - width) / 2), y: Math.round(doc.height * .4), width, height: Math.round(size * 1.13), fill: "#292532", fontFamily: "Arial", fontWeight: style === "heading" ? 700 : 400, fontSize: size, text: value, align: "left", autoFit: true };
}

/** Turns freehand points (canvas coordinates) into a positioned drawing layer. */
export function makeDraw(points: { x: number; y: number }[], color: string, strokeWidth: number, drawTool: "pencil" | "marker" | "highlighter" | "brush" = "pencil"): DesignLayer | null {
  if (points.length < 2) return null;
  const xs = points.map(p => p.x), ys = points.map(p => p.y);
  const pad = Math.max(2, strokeWidth);
  const minX = Math.min(...xs) - pad, minY = Math.min(...ys) - pad;
  const width = Math.max(4, Math.round(Math.max(...xs) - Math.min(...xs) + pad * 2));
  const height = Math.max(4, Math.round(Math.max(...ys) - Math.min(...ys) + pad * 2));
  const local = points.map(p => `${(p.x - minX).toFixed(1)} ${(p.y - minY).toFixed(1)}`);
  let d = `M${local[0]}`;
  for (let i = 1; i < local.length - 1; i++) {
    const [cx, cy] = local[i].split(" "), [nx, ny] = local[i + 1].split(" ");
    d += ` Q${cx} ${cy} ${(Number(cx) + Number(nx)) / 2} ${(Number(cy) + Number(ny)) / 2}`;
  }
  d += ` L${local[local.length - 1]}`;
  return { id: newId(), type: "draw", x: Math.round(minX), y: Math.round(minY), width, height, fill: color, d, strokeWidth, drawTool, opacity: drawTool === "highlighter" ? .32 : drawTool === "marker" ? .58 : 1, naturalWidth: width, naturalHeight: height };
}

export const isGradient = (background: string) => background.includes("gradient");
export function gradientStops(background: string) {
  const colors = background.match(/#[0-9a-f]{3,8}/gi) || [];
  const angle = Number(background.match(/(-?\d+)deg/)?.[1] ?? 135);
  const percents = (background.match(/(\d+(?:\.\d+)?)%/g) || []).map(v => Number(v.replace("%", "")));
  const offsets = percents.length === colors.length && colors.length ? percents : colors.map((_, i) => (i / Math.max(1, colors.length - 1)) * 100);
  return { colors: colors.length ? colors : ["#ffffff", "#dddddd"], angle, offsets: colors.length ? offsets : [0, 100], radial: background.startsWith("radial") };
}

export const templates: DesignTemplate[] = [
  { id: "less-but-better", title: "Less, but better", category: "Presentations", tag: "Minimalist brand presentation", content: { width: 1200, height: 900, background: "#eeeae2", layers: [
    text("THE EVERYDAY STUDIO", 65, 60, 550, 19, "#33392e", { fontWeight: 600 }), photo("/images/interior.jpg", 675, 0, 525, 900),
    text("less,\nbut better.", 65, 270, 690, 108, "#38392e", { fontFamily: "Georgia", italic: true }),
    shape("line", 65, 675, 480, 2, "#a4a495"), text("Thoughtful design. Everyday living.", 65, 720, 570, 21, "#646456"), text("A NEW PERSPECTIVE  /  VOL. 01", 65, 818, 580, 15, "#57594d")] } },
  { id: "good-things", title: "Good things take time", category: "Social media", tag: "Playful Instagram post", content: { width: 1080, height: 1080, background: "#f8cbd7", layers: [
    shape("flower", -35, -60, 390, 390, "#ee7044", { rotation: 10 }), shape("flower", 820, 865, 320, 320, "#ee7044"),
    text("a little reminder", 180, 116, 720, 33, "#8d304d", { fontFamily: "Georgia", italic: true, align: "center" }),
    text("GOOD\nTHINGS\nTAKE TIME.", 90, 295, 900, 139, "#87334c", { fontWeight: 800, align: "center" }),
    shape("star", 829, 159, 103, 103, "#fff8e6", { rotation: 14 }), shape("star", 115, 855, 77, 77, "#fff8e6"),
    text("TRUST YOUR OWN TIMELINE", 180, 925, 720, 22, "#8d304d", { align: "center" })] } },
  { id: "out-of-office", title: "Out of office", category: "Social media", tag: "Summer travel story", pro: true, content: { width: 900, height: 1080, background: "#8caba4", layers: [
    photo("/images/coast.jpg", 0, 0, 900, 1080), shape("rect", 0, 0, 900, 1080, "#15342f", { opacity: .13 }),
    text("SOMEWHERE BY THE SEA", 120, 92, 660, 23, "#fffbea", { align: "center" }),
    text("out of\noffice.", 75, 250, 750, 160, "#fffbea", { fontFamily: "Georgia", italic: true, align: "center" }),
    shape("star", 390, 675, 95, 95, "#fffbea", { rotation: 10 }), shape("rect", 234, 903, 432, 67, "#fffbea", { radius: 34 }),
    text("a little escape is calling", 234, 923, 432, 25, "#466154", { align: "center" })] } },
  { id: "ideas-into-impact", title: "Ideas into impact", category: "Presentations", tag: "Creative pitch deck", content: { width: 1600, height: 1000, background: "#064e48", layers: [
    text("THE NEXT CHAPTER", 105, 90, 1100, 27, "#dcebc4"), text("Ideas into\nimpact.", 95, 295, 1000, 164, "#f3f4d5", { fontWeight: 600 }),
    shape("flower", 1050, 224, 465, 465, "#ddeb9e", { rotation: 15 }), shape("ellipse", 1211, 385, 143, 143, "#064e48"),
    shape("star", 1150, 770, 90, 90, "#ddeb9e", { rotation: 18 }), text("BIG THINKING. REAL POSSIBILITIES.", 108, 881, 1050, 23, "#dcebc4"), text("01 — 2026", 1290, 887, 230, 21, "#dcebc4")] } },
  { id: "sunday-edit", title: "The Sunday edit", category: "Marketing", tag: "Skincare social post", pro: true, content: { width: 900, height: 1080, background: "#ede4d6", layers: [
    photo("/images/skincare.jpg", 0, 385, 900, 695), text("THE SUNDAY EDIT", 90, 69, 720, 24, "#625443", { align: "center" }),
    text("a little\nself-care.", 90, 148, 720, 112, "#625443", { fontFamily: "Georgia", align: "center" }),
    shape("rect", 152, 924, 596, 61, "#f4ecde", { radius: 2 }), text("SLOW DOWN. GLOW UP.", 152, 943, 596, 23, "#625443", { align: "center" })] } },
  { id: "brand-guidelines", title: "Brand guidelines", category: "Presentations", tag: "Modern brand identity", content: { width: 1600, height: 900, background: "#e9e8df", layers: [
    text("morrow®", 93, 75, 700, 50, "#313c30", { fontWeight: 700 }), photo("/images/interior.jpg", 880, 0, 720, 900),
    text("A thoughtful\nbrand,\nby design.", 90, 250, 900, 117, "#313c30", { fontFamily: "Georgia" }), text("BRAND GUIDELINES  /  2026", 97, 806, 780, 23, "#525e4e")] } },
  { id: "summer-sale", title: "Summer sale Instagram post", category: "Social media", tag: "Bold seasonal promotion", content: { width: 1080, height: 1080, background: "#ffddd4", layers: [
    shape("ellipse", 742, -150, 620, 620, "#f36845"), shape("flower", -192, 726, 595, 595, "#ee8060"),
    text("THE SUNNY SIDE OF LIFE", 80, 89, 900, 25, "#a33d28", { align: "center" }),
    text("SUMMER", 60, 290, 960, 132, "#bf4832", { fontWeight: 800, align: "center" }),
    text("looks good\non you.", 100, 450, 880, 125, "#bd4933", { fontFamily: "Georgia", italic: true, align: "center" }),
    shape("rect", 307, 825, 466, 85, "#be4730", { radius: 43 }), text("UP TO 40% OFF", 307, 852, 466, 32, "#fff5e8", { align: "center", fontWeight: 700 })] } },
  { id: "product-launch", title: "Product launch deck", category: "Presentations", tag: "Fresh product presentation", pro: true, content: { width: 1600, height: 900, background: "#e5ddf5", layers: [
    text("INTRODUCING SOMETHING GOOD", 89, 74, 1000, 24, "#55466f"), shape("ellipse", 920, 95, 600, 700, "#c3b1dd"),
    photo("/images/skincare.jpg", 967, 143, 506, 606, { radius: 240 }), text("Meet your\nnext favorite.", 85, 296, 950, 120, "#4c3867", { fontWeight: 600 }),
    text("Made with care. Made for you.", 90, 651, 850, 30, "#655378"), shape("star", 786, 133, 106, 106, "#86709f", { rotation: 16 }), text("PRODUCT LAUNCH  /  2026", 90, 812, 1100, 20, "#655378")] } },
  { id: "weekend-getaway", title: "Weekend getaway", category: "Social media", tag: "Travel photo collage", content: { width: 1200, height: 900, background: "#dce9df", layers: [
    photo("/images/coast.jpg", 575, 60, 557, 779), text("LET'S GO SOMEWHERE", 63, 83, 600, 21, "#275950"),
    text("a weekend\nwell spent.", 60, 275, 730, 97, "#275950", { fontFamily: "Georgia", italic: true }),
    shape("star", 204, 579, 109, 109, "#719e77", { rotation: 15 }), text("COLLECT MOMENTS, NOT THINGS.", 62, 786, 610, 19, "#275950")] } },
  { id: "make-something", title: "Make something great", category: "Print products", tag: "Inspirational poster", content: { width: 900, height: 1080, background: "#ff8250", layers: [
    text("A SMALL IDEA CAN CHANGE EVERYTHING", 61, 73, 790, 18, "#542b26", { align: "center" }),
    text("MAKE\nSOME\nTHING\nGREAT.", 70, 200, 800, 146, "#442b26", { fontWeight: 900 }),
    shape("star", 690, 783, 142, 142, "#fff2c9", { rotation: 13 }), text("GO ON. START CREATING.", 70, 980, 780, 23, "#542b26")] } },
  { id: "daily-notes", title: "A little space to think", category: "Documents", tag: "Daily planner", content: { width: 850, height: 1100, background: "#fbf7ed", layers: [
    text("a little space\nto think.", 72, 84, 720, 84, "#666a4b", { fontFamily: "Georgia", italic: true }),
    text("TODAY'S DATE: __________________", 74, 342, 700, 22, "#7d7e64"), text("MY TOP THREE", 75, 440, 660, 22, "#666a4b", { fontWeight: 700 }),
    ...[510, 587, 664, 820, 897, 974].map(y => shape("line", 74, y, 700, 2, "#cdcbbb")),
    text("A LITTLE GRATITUDE", 74, 749, 700, 22, "#666a4b", { fontWeight: 700 }), shape("flower", 625, 134, 155, 155, "#d6d5a8")] } },
  { id: "creative-portfolio", title: "Hello, I'm a creative", category: "Websites", tag: "Personal portfolio layout", content: { width: 1600, height: 1000, background: "#efece4", layers: [
    text("OLIVIA STUDIO", 95, 66, 700, 27, "#303c35", { fontWeight: 700 }), text("WORK        ABOUT        SAY HELLO ↗", 885, 71, 680, 23, "#303c35"),
    text("Good design.\nGreat stories.", 95, 276, 1190, 149, "#303c35", { fontFamily: "Georgia" }),
    shape("flower", 1163, 391, 300, 300, "#d2abed", { rotation: 12 }), text("Independent designer. Intentional ideas. A little bit of magic.", 98, 682, 1320, 29, "#6b7169"),
    shape("rect", 96, 796, 338, 87, "#303c35", { radius: 44 }), text("EXPLORE MY WORK  ↗", 115, 829, 300, 22, "#f6f0e8", { align: "center" })] } },
  { id: "weekend-vlog", title: "Little moments, big memories", category: "Video", tag: "Travel video cover", content: { width: 1600, height: 900, background: "#8daca1", layers: [
    photo("/images/coast.jpg", 0, 0, 1600, 900), shape("rect", 0, 0, 1600, 900, "#153f35", { opacity: .25 }),
    text("THE WEEKEND DIARIES", 100, 140, 1400, 34, "#fff8df", { align: "center" }),
    text("little moments,\nbig memories.", 150, 300, 1300, 128, "#fff8df", { fontFamily: "Georgia", italic: true, align: "center" }),
    text("a film by you  /  episode 01", 150, 729, 1300, 30, "#fff8df", { align: "center" })] } },
  { id: "coffee-club", title: "The coffee club", category: "Print products", tag: "Café menu and flyer", content: { width: 900, height: 1080, background: "#533728", layers: [
    text("GOOD COFFEE. GOOD COMPANY.", 85, 88, 730, 22, "#f4e4bf", { align: "center" }),
    text("the\ncoffee\nclub.", 100, 246, 700, 157, "#f4e4bf", { fontFamily: "Georgia", align: "center" }),
    shape("flower", 363, 767, 176, 176, "#d7b97a"), text("YOUR DAILY DOSE OF SOMETHING GOOD", 80, 987, 740, 20, "#f4e4bf", { align: "center" })] } },
  { id: "meadow-notes", title: "A quiet hello", category: "Social media", tag: "Nature quote post", content: { width: 1080, height: 1080, background: "linear-gradient(160deg, #fef3c7 0%, #fbcfe8 100%)", layers: [
    photo("/images/photos/flowers.jpg", 0, 0, 1080, 1080), shape("rect", 0, 0, 1080, 1080, "#fffbeb", { opacity: .38 }),
    shape("pattern", 0, 0, 1080, 1080, "#7c4a2d", { pattern: "dots", tile: 74, opacity: .35 }),
    text("a quiet hello", 90, 355, 900, 104, "#5b3a24", { fontFamily: "Georgia", italic: true, align: "center" }),
    shape("stroke", 300, 560, 480, 18, "#7c4a2d", { variant: "dashed", strokeWidth: 5 }),
    text("SLOW MORNINGS, SOFT LIGHT", 140, 620, 800, 24, "#6b4a30", { align: "center" })] } },
  { id: "menu-card", title: "The little menu", category: "Print products", tag: "Café table card with prices", content: { width: 850, height: 1100, background: "#fdf8ee", layers: [
    text("the little menu", 60, 78, 730, 74, "#5d4630", { fontFamily: "Georgia", italic: true, align: "center" }),
    shape("stroke", 200, 195, 450, 14, "#a98b62", { variant: "double", strokeWidth: 4 }),
    { id: "menu-table", type: "table", x: 90, y: 265, width: 670, height: 560, fill: "#8c6a45", rows: 6, cols: 2, cellFill: "#fffdf7", lineColor: "#d8c3a1",
      cells: ["Espresso", "3.50", "Flat white", "4.20", "Cold brew", "4.80", "Matcha latte", "5.00", "Croissant", "3.20", "Banana bread", "3.80"] },
    text("MADE FRESH, EVERY MORNING", 90, 930, 670, 22, "#8c6a45", { align: "center" })] } },
  /* ── Print shop catalogue ─────────────────────────────────────────────── */
  { id: "studio-business-card", title: "The straightforward studio", category: "Business card", tag: "Minimalist visiting card", content: { width: 1050, height: 600, background: "#f7f4ed", layers: [
    shape("rect", 0, 0, 350, 600, "#1f3d34"), shape("flower", -120, 360, 330, 330, "#3f6d5b"),
    text("AURA", 52, 62, 240, 44, "#f4f1e7", { fontWeight: 700, letterSpacing: 6 }),
    text("DESIGN STUDIO", 54, 122, 250, 14, "#9dbcae", { letterSpacing: 3 }),
    text("Riya Sharma", 405, 168, 580, 54, "#22322b", { fontFamily: "Georgia" }),
    text("FOUNDER  ·  CREATIVE DIRECTOR", 407, 240, 560, 17, "#6d7a70", { letterSpacing: 2 }),
    shape("line", 407, 300, 130, 2, "#c2b69f"),
    text("+91 98400 21188\nhello@aurastudio.in\nwww.aurastudio.in", 407, 344, 560, 21, "#4a554d", { lineHeight: 1.85 }),
    text("12 Marine Lane, Fort, Mumbai 400001", 407, 512, 590, 17, "#8a9389")] } },
  { id: "corner-cafe-card", title: "The corner café card", category: "Business card", tag: "Warm café visiting card", pro: true, content: { width: 1050, height: 600, background: "#3f2a1d", layers: [
    photo("/images/photos/coffee.jpg", 0, 0, 1050, 600), shape("rect", 0, 0, 1050, 600, "#2c1c12", { opacity: .62 }),
    shape("stroke", 330, 96, 390, 14, "#d7b97a", { variant: "double", strokeWidth: 4 }),
    text("corner café", 200, 165, 650, 92, "#f6e6c4", { fontFamily: "Georgia", italic: true, align: "center" }),
    text("ROASTED DAILY  ·  SINCE 2014", 250, 300, 550, 19, "#d7b97a", { align: "center", letterSpacing: 3 }),
    text("Open 7:30 – 21:00   ·   +91 99000 45611   ·   thecornercafe.in", 140, 472, 770, 20, "#f0dfbe", { align: "center" })] } },
  { id: "staff-id-card", title: "Staff identity card", category: "ID card", tag: "Employee ID with photo", content: { width: 660, height: 1040, background: "#ffffff", layers: [
    shape("rect", 0, 0, 660, 250, "#2b4a8b"), shape("flower", 470, -50, 250, 250, "#4d70bb"),
    text("MERIDIAN", 44, 56, 420, 38, "#ffffff", { fontWeight: 700, letterSpacing: 4 }),
    text("PVT. LTD.", 46, 106, 400, 15, "#c3d3f2", { letterSpacing: 3 }),
    text("EMPLOYEE IDENTITY CARD", 46, 188, 570, 17, "#dce6fb", { letterSpacing: 2 }),
    photo("/images/photos/desk.jpg", 62, 300, 240, 300, { radius: 18 }),
    text("Ananya Verma", 62, 636, 540, 42, "#1e2a44", { fontWeight: 700 }),
    text("Senior Graphic Designer\nDesign & Packaging", 64, 694, 540, 21, "#5a6a86", { lineHeight: 1.7 }),
    shape("line", 62, 786, 536, 2, "#dfe4ee"),
    text("ID NO.  MRD-2026-0417\nDOB      12 APR 1998\nBLOOD  B+", 64, 824, 540, 20, "#3c4a66", { lineHeight: 1.85, letterSpacing: 1 }),
    shape("rect", 62, 930, 536, 62, "#eef2fb", { radius: 10 }),
    text("Authorised signatory", 62, 952, 536, 18, "#5a6a86", { align: "center" })] } },
  { id: "visitor-pass", title: "Visitor pass", category: "ID card", tag: "Landscape visitor badge", content: { width: 1013, height: 638, background: "#ffffff", layers: [
    shape("rect", 0, 0, 1013, 112, "#8b1e2d"),
    text("MERIDIAN", 44, 28, 500, 34, "#ffffff", { fontWeight: 700, letterSpacing: 4 }),
    text("VISITOR PASS", 660, 42, 310, 22, "#ffe0c2", { align: "right", letterSpacing: 3 }),
    photo("/images/photos/desk.jpg", 44, 168, 250, 300, { radius: 14 }),
    text("Guest Name", 330, 168, 620, 48, "#1e2a44", { fontWeight: 700 }),
    text("Company  ____________________\nPurpose of visit  _____________\nValid until  __________________\nIssued by  ____________________", 332, 250, 620, 21, "#5a6a86", { lineHeight: 2 }),
    shape("rect", 330, 500, 630, 62, "#f4e4e6", { radius: 10 }),
    text("PLEASE WEAR THIS BADGE AT ALL TIMES", 330, 522, 630, 18, "#8b1e2d", { align: "center", letterSpacing: 2 })] } },
  { id: "studio-letterhead", title: "Everyday studio letterhead", category: "Letterhead", tag: "A4 letterhead with footer", content: { width: 850, height: 1100, background: "#ffffff", layers: [
    shape("rect", 0, 0, 850, 132, "#123f38"), shape("flower", 690, 24, 140, 140, "#2f6b5d"),
    text("MERIDIAN", 64, 46, 420, 40, "#ffffff", { fontWeight: 700, letterSpacing: 5 }),
    text("DESIGN & PRINT STUDIO", 66, 96, 420, 14, "#a9c6be", { letterSpacing: 3 }),
    text("Date: ______________________", 64, 200, 500, 20, "#4d635c"),
    text("To,\n____________________________\n\nSubject: ______________________________\n\nDear Sir / Madam,\n\nWe are pleased to share our latest collection of print and brand design services. The enclosed details cover visiting cards, letterheads, envelopes, brochures and large-format printing.\n\nPlease feel free to reach out with any questions, and thank you for your continued trust in our studio.", 64, 262, 722, 21, "#3c4a46", { lineHeight: 1.95 }),
    shape("line", 64, 892, 722, 2, "#dfe6e2"),
    text("Warm regards,\nRiya Sharma  ·  Founder", 64, 930, 520, 20, "#22352f", { lineHeight: 1.8 }),
    text("meridianstudio.in  ·  +91 98400 21188", 420, 1030, 366, 15, "#7d8c86", { align: "right" })] } },
  { id: "dl-envelope", title: "DL window envelope", category: "Envelope", tag: "Business envelope layout", content: { width: 1000, height: 500, background: "#faf7ef", layers: [
    shape("pattern", 0, 0, 1000, 500, "#c8b89a", { pattern: "stripes", tile: 46, opacity: .32 }),
    text("MERIDIAN", 56, 58, 380, 30, "#1f3d34", { fontWeight: 700, letterSpacing: 4 }),
    text("DESIGN & PRINT STUDIO", 58, 100, 380, 13, "#6c7d74", { letterSpacing: 2 }),
    text("Riya Sharma\n12 Marine Lane, Fort\nMumbai 400001\n+91 98400 21188", 56, 250, 400, 19, "#3c4a46", { lineHeight: 1.85 }),
    shape("rect", 600, 148, 340, 168, "#ffffff", { radius: 3 }),
    shape("line", 600, 148, 340, 3, "#c8b89a"), shape("line", 600, 313, 340, 3, "#c8b89a"),
    text("to:", 630, 176, 280, 17, "#8a9389", { italic: true }),
    shape("stroke", 90, 400, 240, 12, "#c8b89a", { variant: "dashed", strokeWidth: 3 }),
    text("30 mm window  ·  ISO DL 220 × 110 mm", 620, 400, 320, 15, "#8a9389", { align: "right" })] } },
  { id: "mega-sale-flyer", title: "The mega sale flyer", category: "Flayer", tag: "Promotional offer flyer", content: { width: 1000, height: 1400, background: "#ffe27a", layers: [
    shape("ellipse", -170, -170, 640, 640, "#ff5f4d"), shape("ellipse", 650, 1040, 580, 580, "#2b2b6b"),
    text("LIMITED TIME OFFER", 120, 128, 760, 24, "#7c2a12", { align: "center", letterSpacing: 4 }),
    text("MEGA\nSALE", 100, 250, 800, 190, "#8c2711", { fontWeight: 900, align: "center", lineHeight: 1.05 }),
    text("up to 60% off", 150, 640, 700, 62, "#2b2b6b", { fontFamily: "Georgia", italic: true, align: "center" }),
    shape("rect", 250, 762, 500, 92, "#2b2b6b", { radius: 46 }),
    text("SHOP 1 – 7 JAN", 250, 792, 500, 32, "#ffe9a8", { align: "center", fontWeight: 700, letterSpacing: 2 }),
    text("Fashion  ·  Home  ·  Electronics\n12 Marine Lane, Fort, Mumbai\n+91 98400 21188", 120, 950, 760, 26, "#5a2a18", { align: "center", lineHeight: 1.8 })] } },
  { id: "weekend-market-flyer", title: "Weekend market flyer", category: "Flayer", tag: "Event flyer with photo", content: { width: 1000, height: 1400, background: "#f2f6f0", layers: [
    photo("/images/photos/meadow.jpg", 0, 0, 1000, 660),
    text("EVERY SATURDAY & SUNDAY", 90, 96, 820, 24, "#2f4a35", { align: "center", letterSpacing: 5 }),
    text("the green\nmarket", 120, 250, 760, 138, "#26402c", { fontFamily: "Georgia", italic: true, align: "center", lineHeight: 1.3 }),
    text("FARM FRESH  ·  HANDMADE  ·  LIVE MUSIC", 100, 706, 800, 28, "#3d5c44", { align: "center", letterSpacing: 2 }),
    shape("line", 300, 772, 400, 3, "#a8bfa9"),
    text("8 AM – 2 PM\nRiverside Park, Fort\nFree entry  ·  All welcome\n@thegreenmarket", 120, 830, 760, 40, "#48604e", { align: "center", lineHeight: 1.75 }),
    shape("rect", 260, 1142, 480, 86, "#2f6b3f", { radius: 43 }),
    text("SAVE THE DATE", 260, 1168, 480, 30, "#f2f6f0", { align: "center", fontWeight: 700 })] } },
  { id: "product-brochure", title: "The product brochure", category: "Boucher", tag: "Two-panel brochure spread", content: { width: 1400, height: 1000, background: "#ffffff", layers: [
    shape("rect", 0, 0, 700, 1000, "#1d3d63"), photo("/images/interior.jpg", 0, 0, 700, 470),
    text("MERIDIAN", 56, 520, 500, 30, "#ffffff", { fontWeight: 700, letterSpacing: 4 }),
    text("Design that works\nas beautifully\nas it looks.", 56, 592, 590, 52, "#dfe8f4", { fontFamily: "Georgia", lineHeight: 1.5 }),
    text("Branding  ·  Print  ·  Packaging  ·  Signage", 56, 884, 600, 20, "#9fb8d4", { letterSpacing: 1 }),
    shape("line", 760, 96, 120, 3, "#c2ccd8"),
    text("WHAT WE DO", 760, 134, 400, 18, "#2c3e57", { letterSpacing: 3 }),
    text("Brand identity\nPackaging design\nMarketing collateral\nExhibition graphics", 758, 200, 570, 38, "#1d3d63", { fontFamily: "Georgia", lineHeight: 1.6 }),
    shape("line", 760, 500, 570, 2, "#dfe4ea"),
    text("HOW IT WORKS", 760, 540, 400, 18, "#2c3e57", { letterSpacing: 3 }),
    text("01   Discovery call\n02   Concept & mockups\n03   Design refinement\n04   Print & delivery", 758, 602, 570, 26, "#45566f", { lineHeight: 1.85 }),
    text("meridianstudio.in  ·  hello@meridianstudio.in", 758, 908, 570, 18, "#7d8b9c")] } },
  { id: "mug-wrap-design", title: "Morning coffee mug wrap", category: "Mug", tag: "Wrap design for an 11 oz mug", content: { width: 2400, height: 1100, background: "#fdf6ec", layers: [
    shape("rect", 0, 0, 2400, 1100, "#ffe0c2", { opacity: .5 }),
    shape("pattern", 0, 0, 2400, 1100, "#d29a76", { pattern: "confetti", tile: 120, opacity: .35 }),
    shape("rect", 150, 150, 2100, 800, "#ffffff", { radius: 40 }),
    text("a little\nhappier", 300, 300, 1800, 200, "#8c4a2f", { fontFamily: "Georgia", italic: true, align: "center", lineHeight: 1.3 }),
    text("WITH EVERY SIP", 300, 680, 1800, 78, "#a9704f", { align: "center", letterSpacing: 6 }),
    text("✦   GOOD MORNING   ✦", 300, 802, 1800, 52, "#c08a63", { align: "center", letterSpacing: 8 })] } },
  { id: "tee-front-print", title: "Everyday tee front print", category: "T-Shirt", tag: "Front print for a cotton tee", content: { width: 1800, height: 2400, background: "#ffffff", layers: [
    shape("ellipse", 400, 340, 1000, 1000, "#1f3d34"), shape("star", 790, 690, 220, 220, "#ffd66b", { rotation: 12 }),
    text("MAKE", 250, 1580, 1300, 190, "#1f3d34", { fontWeight: 900, align: "center", letterSpacing: 6 }),
    text("it yours", 250, 1810, 1300, 148, "#1f3d34", { fontFamily: "Georgia", italic: true, align: "center" }),
    text("EST. 2026  ·  HANDMADE STREETWEAR", 250, 2120, 1300, 50, "#7d8c7f", { align: "center", letterSpacing: 6 })] } },
  { id: "hardbound-diary", title: "Hardbound diary cover", category: "Dairie", tag: "2026 diary cover design", content: { width: 1000, height: 1400, background: "#20404a", layers: [
    shape("pattern", 0, 0, 1000, 1400, "#7fd1c1", { pattern: "dots", tile: 60, opacity: .25 }),
    text("2026", 90, 150, 820, 200, "#f0e2c8", { fontFamily: "Georgia", align: "center", letterSpacing: 10 }),
    shape("line", 330, 408, 340, 3, "#c9a227"),
    text("A YEAR OF\nSMALL WINS", 120, 470, 760, 90, "#f0e2c8", { fontWeight: 700, align: "center", lineHeight: 1.4, letterSpacing: 4 }),
    shape("flower", 405, 800, 190, 190, "#c9a227"),
    text("Name  ______________________", 140, 1100, 720, 26, "#a9c8c2"),
    text("MERIDIAN STUDIO", 140, 1250, 720, 24, "#7fd1c1", { align: "center", letterSpacing: 6 })] } },
  { id: "bill-voucher-book", title: "Bill & voucher book", category: "Bill & Vouch Book", tag: "Invoice page with acknowledgement", content: { width: 1200, height: 800, background: "#ffffff", layers: [
    shape("rect", 0, 0, 1200, 104, "#123f38"),
    text("MERIDIAN TRADERS", 44, 28, 600, 30, "#ffffff", { fontWeight: 700, letterSpacing: 3 }),
    text("TAX INVOICE", 44, 68, 600, 16, "#a9c6be", { letterSpacing: 4 }),
    text("Invoice No. 0271\nDate: 12 / 01 / 2026", 780, 30, 380, 19, "#dcebe6", { align: "right", lineHeight: 1.7 }),
    text("Billed to:  ______________________\nGSTIN:  ________________________", 44, 132, 560, 19, "#3c4a46", { lineHeight: 1.9 }),
    { id: "bill-table", type: "table", x: 44, y: 216, width: 1112, height: 288, fill: "#123f38", rows: 5, cols: 5, cellFill: "#ffffff", lineColor: "#cfdcd7", lineWidth: 1, headerFill: "#e8f1ee",
      cells: ["Particulars", "Qty", "Rate", "Tax", "Amount", "Visiting cards 300 gsm", "1,000", "1.20", "18%", "1,416.00", "Letterheads A4", "500", "4.50", "18%", "2,655.00", "Flex banner 6 × 3 ft", "2", "480.00", "18%", "1,132.80", "Delivery & installation", "1", "350.00", "—", "350.00"] },
    text("Subtotal\nCGST\nSGST\nTotal payable", 700, 540, 250, 20, "#3c4a46", { align: "right", lineHeight: 1.75 }),
    text("5,553.80\n499.84\n499.84\n₹ 6,553.48", 960, 540, 196, 20, "#123f38", { align: "right", lineHeight: 1.75, fontWeight: 700 }),
    shape("line", 44, 682, 1112, 2, "#dfe6e2"),
    text("Receiver's signature", 44, 706, 300, 18, "#7d8c86"),
    text("For MERIDIAN TRADERS  ·  Authorised signatory", 700, 706, 456, 18, "#7d8c86", { align: "right" }),
    text("Acknowledgement copy", 44, 752, 400, 16, "#b0b8bd", { letterSpacing: 2 })] } },
  { id: "flex-banner", title: "Shop flex banner", category: "Banner", tag: "6 × 3 ft flex banner", content: { width: 2000, height: 800, background: "#0e2f6b", layers: [
    shape("pattern", 0, 0, 2000, 800, "#ffd166", { pattern: "stripes", tile: 90, opacity: .18 }),
    shape("ellipse", -260, -240, 900, 900, "#ff8a3d"), shape("ellipse", 1620, 280, 700, 700, "#ffd166"),
    text("GRAND OPENING", 200, 126, 1600, 72, "#ffe9a8", { align: "center", fontWeight: 800, letterSpacing: 10 }),
    text("New Showroom", 200, 262, 1600, 176, "#ffffff", { fontWeight: 900, align: "center", fontFamily: "Georgia" }),
    text("Saturday, 17 January  ·  10 AM onwards", 200, 500, 1600, 52, "#dbe6ff", { align: "center", letterSpacing: 3 }),
    text("Flat 40% off on all print products  ·  Free home delivery", 200, 592, 1600, 44, "#ffd166", { align: "center" })] } },
  { id: "photo-frame-gift", title: "Personalised photo frame", category: "Customise Gift", tag: "Photo gift with a message", content: { width: 1200, height: 1200, background: "#f6ece0", layers: [
    shape("pattern", 0, 0, 1200, 1200, "#c98d63", { pattern: "checks", tile: 80, opacity: .22 }),
    shape("rect", 130, 130, 940, 940, "#ffffff", { radius: 8 }),
    photo("/images/photos/flowers.jpg", 190, 190, 820, 520, { radius: 6 }),
    text("for you, always", 190, 748, 820, 90, "#6b4a35", { fontFamily: "Georgia", italic: true, align: "center" }),
    text("“A little gift, a lot of love.”", 190, 894, 820, 40, "#8a6a4f", { align: "center" }),
    text("— with love, from home", 190, 972, 820, 28, "#a3866c", { align: "center" })] } },
  { id: "thank-you-card", title: "Thank you card", category: "More", tag: "Greeting card for gifts", content: { width: 1200, height: 900, background: "#ffffff", layers: [
    shape("rect", 0, 0, 600, 900, "#f3d9c8"), shape("flower", 380, 560, 340, 340, "#e0a882"),
    text("THANK\nYOU", 90, 150, 420, 66, "#7a4630", { fontWeight: 800, letterSpacing: 6, lineHeight: 1.3 }),
    text("for the little things\nand the big ones too.", 90, 330, 440, 36, "#8f5c40", { fontFamily: "Georgia", lineHeight: 1.7 }),
    shape("line", 560, 130, 80, 3, "#a98a78"),
    text("with gratitude,\nyour name here.", 660, 400, 460, 46, "#6b4a38", { fontFamily: "Georgia", lineHeight: 1.7 }),
    text("✦", 940, 700, 140, 60, "#c9a184", { align: "center" })] } },
  { id: "sticker-sheet", title: "Handmade sticker sheet", category: "More", tag: "Round sticker sheet layout", content: { width: 1080, height: 1080, background: "#fffdf7", layers: [
    shape("ellipse", 70, 70, 300, 300, "#ffd166"), text("GOOD\nDAY", 70, 150, 300, 44, "#7a5410", { align: "center", fontWeight: 800, lineHeight: 1.3 }),
    shape("flower", 430, 90, 240, 240, "#ff8a8a"), shape("star", 740, 90, 260, 260, "#7fd1c1", { rotation: 12 }),
    shape("rect", 70, 430, 380, 220, "#c7b8f5", { radius: 110 }), text("HELLO!", 70, 508, 380, 54, "#4a3a86", { align: "center", fontWeight: 700 }),
    shape("ellipse", 500, 430, 330, 330, "#ffb4a2"), text("☺", 500, 545, 330, 90, "#8c3a25", { align: "center" }),
    shape("ellipse", 110, 700, 330, 330, "#a3d9a5"), text("★\nKEEP GOING", 110, 800, 330, 40, "#2f5f34", { align: "center", fontWeight: 700, lineHeight: 1.4 }),
    shape("flower", 520, 800, 300, 300, "#ffe082"), shape("star", 850, 700, 160, 160, "#c78ff0")] } },
];

export const recentTemplateIds = ["brand-guidelines", "studio-business-card", "mega-sale-flyer", "staff-id-card"];
export const categories = ["All", "Business card", "ID card", "Letterhead", "Envelope", "Flayer", "Boucher", "Mug", "T-Shirt", "Dairie", "Bill & Vouch Book", "Banner", "Customise Gift", "Social Media", "Websites", "Video", "More"];
export const cloneDocument = (document: DesignDocument): DesignDocument => JSON.parse(JSON.stringify(document));
export const blankDocument = (width = 1080, height = 1080): DesignDocument => ({ width, height, background: "#ffffff", layers: [] });

const COLORS = /^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i;
const validColor = (color: unknown) => typeof color === "string" && (COLORS.test(color) || color === "transparent");
const validBackground = (value: unknown) => typeof value === "string" && value.length <= 220 && (COLORS.test(value) || ((/^linear-gradient\(\s*-?\d+deg(,\s*#[0-9a-f]{3,8}\s+\d+%)+\s*\)$/i.test(value) || /^radial-gradient\(\s*circle(,\s*#[0-9a-f]{3,8}\s+\d+%)+\s*\)$/i.test(value)) && (value.match(/#[0-9a-f]{3,8}/gi) || []).length <= 8));
const num = (value: unknown, min: number, max: number) => Number.isFinite(value) && (value as number) >= min && (value as number) <= max;
const LAYER_TYPES: LayerType[] = ["text", "rect", "ellipse", "image", "star", "flower", "line", "icon", "shape", "stroke", "table", "draw", "pattern"];

function isFractionList(value: unknown, expected: number) {
  if (!Array.isArray(value) || value.length !== expected || value.length > 20) return false;
  if (!value.every(v => Number.isFinite(v) && v >= 0.02 && v <= 1)) return false;
  const total = value.reduce((sum: number, v: number) => sum + v, 0);
  return Math.abs(total - 1) < 0.02;
}

export function isValidEffects(value: unknown): value is LayerEffects {
  if (!value || typeof value !== "object") return false;
  const e = value as LayerEffects;
  const unit = (v: unknown) => v === undefined || num(v, 0, 1);
  if (e.shadow !== undefined && !(validColor(e.shadow.color) && num(e.shadow.blur, 0, 200) && num(e.shadow.x, -200, 200) && num(e.shadow.y, -200, 200) && num(e.shadow.opacity, 0, 1))) return false;
  if (e.glow !== undefined && !(validColor(e.glow.color) && num(e.glow.blur, 0, 200) && num(e.glow.opacity, 0, 1))) return false;
  if (e.outline !== undefined && !(validColor(e.outline.color) && num(e.outline.width, 0, 100))) return false;
  if (e.blur !== undefined && !num(e.blur, 0, 100)) return false;
  if (e.brightness !== undefined && !num(e.brightness, 0, 3)) return false;
  if (e.contrast !== undefined && !num(e.contrast, 0, 3)) return false;
  if (e.saturation !== undefined && !num(e.saturation, 0, 3)) return false;
  if (!unit(e.grayscale) || !unit(e.sepia)) return false;
  if (e.flipX !== undefined && typeof e.flipX !== "boolean") return false;
  return e.flipY === undefined || typeof e.flipY === "boolean";
}

/** True when the effects object carries nothing that changes rendering. */
export function hasEffects(effects?: LayerEffects) {
  if (!effects) return false;
  return !!(effects.shadow || effects.glow || effects.outline || effects.blur || effects.flipX || effects.flipY
    || (effects.brightness !== undefined && effects.brightness !== 1) || (effects.contrast !== undefined && effects.contrast !== 1)
    || (effects.saturation !== undefined && effects.saturation !== 1) || effects.grayscale || effects.sepia);
}

export type TextCase = "upper" | "lower" | "title" | "sentence" | "toggle";
export function transformCase(text: string, mode: TextCase) {
  switch (mode) {
    case "upper": return text.toUpperCase();
    case "lower": return text.toLowerCase();
    case "title": return text.toLowerCase().replace(/(^|[\s\-—("'])([\p{L}])/gu, (_, lead, ch) => lead + ch.toUpperCase());
    case "sentence": return text.toLowerCase().replace(/(^|[.!?\n]\s*)([\p{L}])/gu, (_, lead, ch) => lead + ch.toUpperCase());
    case "toggle": return Array.from(text).map(ch => ch === ch.toUpperCase() ? ch.toLowerCase() : ch.toUpperCase()).join("");
  }
}

export function isValidDocument(value: unknown): value is DesignDocument {
  if (!value || typeof value !== "object") return false;
  const doc = value as DesignDocument;
  if (!num(doc.width, 64, 5000) || !num(doc.height, 64, 5000) || !Number.isInteger(doc.width) || !Number.isInteger(doc.height)) return false;
  if (!validBackground(doc.background) || !Array.isArray(doc.layers) || doc.layers.length > MAX_LAYERS) return false;
  if (new Set(doc.layers.map(layer => (layer as DesignLayer)?.id)).size !== doc.layers.length) return false;
  return doc.layers.every(layer => {
    if (!layer || typeof layer !== "object" || typeof layer.id !== "string" || !/^[a-z0-9_-]{1,100}$/i.test(layer.id)) return false;
    if (!LAYER_TYPES.includes(layer.type)) return false;
    if (![layer.x, layer.y, layer.width, layer.height].every(v => num(v, -20000, 20000)) || layer.width <= 0 || layer.height <= 0) return false;
    if (!validColor(layer.fill)) return false;
    if (layer.fontSize !== undefined && !num(layer.fontSize, 1, 1000)) return false;
    if (layer.fontWeight !== undefined && !num(layer.fontWeight, 100, 900)) return false;
    if (layer.underline !== undefined && typeof layer.underline !== "boolean") return false;
    if (layer.strikethrough !== undefined && typeof layer.strikethrough !== "boolean") return false;
    if (layer.letterSpacing !== undefined && !num(layer.letterSpacing, -100, 1000)) return false;
    if (layer.lineHeight !== undefined && !num(layer.lineHeight, .8, 3)) return false;
    if (layer.fontFamily !== undefined && (typeof layer.fontFamily !== "string" || layer.fontFamily.length > 120 || !/^[\w .,'\-]+$/.test(layer.fontFamily))) return false;
    if (layer.align !== undefined && !["left", "center", "right", "justify", "justify-all"].includes(layer.align)) return false;
    if (layer.listStyle !== undefined && !["none", "bullet", "number", "dash", "arrow", "check", "star", "diamond"].includes(layer.listStyle)) return false;
    if (layer.wordSpacing !== undefined && !num(layer.wordSpacing, 0.2, 5)) return false;
    if (layer.firstLineIndent !== undefined && !num(layer.firstLineIndent, -500, 2000)) return false;
    if (layer.paraSpacing !== undefined && !num(layer.paraSpacing, 0, 1000)) return false;
    if (layer.listBulletVariant !== undefined && !["bullet", "circle", "square", "check", "arrow", "diamond", "star", "dash"].includes(layer.listBulletVariant)) return false;
    if (layer.listNumberFormat !== undefined && !["number", "number-paren", "alpha-lower", "alpha-lower-paren", "alpha-upper", "roman-lower", "roman-upper"].includes(layer.listNumberFormat)) return false;
    if (layer.listStart !== undefined && (!Number.isInteger(layer.listStart) || layer.listStart < 1 || layer.listStart > 10000)) return false;
    if (layer.dropCap !== undefined && typeof layer.dropCap !== "boolean") return false;
    if (layer.dropCapLines !== undefined && !num(layer.dropCapLines, 2, 10)) return false;
    if (layer.dropCapMargin !== undefined && typeof layer.dropCapMargin !== "boolean") return false;
    if (layer.dropCapGap !== undefined && !num(layer.dropCapGap, 0, 2000)) return false;
    if (layer.dropCapFont !== undefined && (typeof layer.dropCapFont !== "string" || layer.dropCapFont.length > 120)) return false;
    if (layer.dropCapFill !== undefined && !validColor(layer.dropCapFill)) return false;
    if (layer.paraLevels !== undefined && (!Array.isArray(layer.paraLevels) || layer.paraLevels.length > 500 || !layer.paraLevels.every(l => Number.isInteger(l) && l >= 0 && l <= 8))) return false;
    if (layer.scriptSize !== undefined && !num(layer.scriptSize, 20, 100)) return false;
    if (layer.scriptShift !== undefined && !num(layer.scriptShift, 0, 400)) return false;
    if (layer.script !== undefined && !["sub", "super"].includes(layer.script)) return false;
    if (layer.scriptRanges !== undefined && (!Array.isArray(layer.scriptRanges) || layer.scriptRanges.length > 200 || !layer.scriptRanges.every(r => r && Number.isInteger(r.start) && Number.isInteger(r.end) && r.start >= 0 && r.start < r.end && r.end <= (layer.text || "").length && (r.kind === "sub" || r.kind === "super")))) return false;
    if (layer.groupId !== undefined && (typeof layer.groupId !== "string" || layer.groupId.length > 100)) return false;
    if (layer.groupLocked !== undefined && typeof layer.groupLocked !== "boolean") return false;
    if (layer.rotation !== undefined && !num(layer.rotation, -360, 360)) return false;
    if (layer.opacity !== undefined && !num(layer.opacity, 0, 1)) return false;
    if (layer.opacityFade !== undefined && !isOpacityFade(layer.opacityFade)) return false;
    if (layer.fillAlpha !== undefined && !num(layer.fillAlpha, 0, 1)) return false;
    if (layer.radius !== undefined && !num(layer.radius, 0, 5000)) return false;
    if (layer.strokeWidth !== undefined && !num(layer.strokeWidth, .5, 400)) return false;
    if (layer.text !== undefined && (typeof layer.text !== "string" || layer.text.length > 5000)) return false;
    if (layer.src !== undefined && (typeof layer.src !== "string" || layer.src.length > 4_000_000 || !(/^\/images\/[a-z0-9/_-]+\.(jpe?g|png|webp)$/i.test(layer.src) || /^data:image\/(png|jpeg|webp);base64,/.test(layer.src)))) return false;
    if (layer.path !== undefined && (typeof layer.path !== "string" || layer.path.length > 4000)) return false;
    if (layer.d !== undefined && (typeof layer.d !== "string" || layer.d.length > 400_000)) return false;
    if (layer.drawTool !== undefined && !["pencil", "marker", "highlighter", "brush"].includes(layer.drawTool)) return false;
    if (layer.erased !== undefined && (!Array.isArray(layer.erased) || layer.erased.length > 4000 || !layer.erased.every(e => Array.isArray(e) && (e.length === 3 || e.length === 4) && e.every(n => Number.isFinite(n))))) return false;
    if (layer.naturalWidth !== undefined && !num(layer.naturalWidth, 1, 20000)) return false;
    if (layer.naturalHeight !== undefined && !num(layer.naturalHeight, 1, 20000)) return false;
    if (layer.shape !== undefined && (typeof layer.shape !== "string" || layer.shape.length > 40)) return false;
    if (layer.variant !== undefined && (typeof layer.variant !== "string" || layer.variant.length > 24)) return false;
    if (layer.pattern !== undefined && (typeof layer.pattern !== "string" || !["dots", "grid", "stripes", "checks", "waves", "confetti"].includes(layer.pattern))) return false;
    if (layer.tile !== undefined && !num(layer.tile, 8, 2000)) return false;
    if (layer.cellFill !== undefined && !validColor(layer.cellFill)) return false;
    if (layer.lineColor !== undefined && !validColor(layer.lineColor)) return false;
    if (layer.rows !== undefined && (!Number.isInteger(layer.rows) || layer.rows < 1 || layer.rows > 20)) return false;
    if (layer.cols !== undefined && (!Number.isInteger(layer.cols) || layer.cols < 1 || layer.cols > 12)) return false;
    if (layer.cells !== undefined) {
      if (!Array.isArray(layer.cells) || layer.cells.length > 240 || layer.rows === undefined || layer.cols === undefined || layer.cells.length !== layer.rows * layer.cols) return false;
      if (!layer.cells.every(cell => typeof cell === "string" && cell.length <= 160)) return false;
    }
    if (typeof layer.outline !== "undefined" && typeof layer.outline !== "boolean") return false;
    if (typeof layer.autoFit !== "undefined" && typeof layer.autoFit !== "boolean") return false;
    if (typeof layer.qr !== "undefined" && !isQRSettings(layer.qr)) return false;
    if (layer.originalSrc !== undefined && (typeof layer.originalSrc !== "string" || layer.originalSrc.length > 4_000_000 || !(/^\/images\/[a-z0-9/_-]+\.(jpe?g|png|webp)$/i.test(layer.originalSrc) || /^data:image\/(png|jpeg|webp);base64,/.test(layer.originalSrc)))) return false;
    if (layer.effects !== undefined && !isValidEffects(layer.effects)) return false;
    if (layer.colWidths !== undefined && !isFractionList(layer.colWidths, layer.cols || 1)) return false;
    if (layer.rowHeights !== undefined && !isFractionList(layer.rowHeights, layer.rows || 1)) return false;
    if (layer.lineWidth !== undefined && !num(layer.lineWidth, 0, 60)) return false;
    if (layer.headerFill !== undefined && !validColor(layer.headerFill)) return false;
    if (!isTableAppearance(layer)) return false;
    if (layer.fillGradient !== undefined && !isGradientFill(layer.fillGradient)) return false;
    if (layer.fillImage !== undefined && (typeof layer.fillImage !== "string" || layer.fillImage.length > 4_000_000 || !(/^\/images\/[a-z0-9/_-]+\.(jpe?g|png|webp)$/i.test(layer.fillImage) || /^data:image\/(png|jpeg|webp);base64,/.test(layer.fillImage)))) return false;
    if (layer.fillImageZoom !== undefined && !num(layer.fillImageZoom, 1, 5)) return false;
    if (layer.fillImageX !== undefined && !num(layer.fillImageX, 0, 1)) return false;
    if (layer.fillImageY !== undefined && !num(layer.fillImageY, 0, 1)) return false;
    if (layer.textStrokeColor !== undefined && !validColor(layer.textStrokeColor)) return false;
    if (layer.textStrokeWidth !== undefined && !num(layer.textStrokeWidth, 0, 80)) return false;
    if (layer.textFillTransparent !== undefined && typeof layer.textFillTransparent !== "boolean") return false;
    if (layer.curve !== undefined && !num(layer.curve, -360, 360)) return false;
    if (layer.cropZoom !== undefined && !num(layer.cropZoom, 1, 4)) return false;
    if (layer.cropX !== undefined && !num(layer.cropX, 0, 1)) return false;
    if (layer.cropY !== undefined && !num(layer.cropY, 0, 1)) return false;
    if (layer.mask !== undefined && (typeof layer.mask !== "string" || !["none", "circle", "rounded", "heart", "star", "diamond", "hexagon", "blob", "flower"].includes(layer.mask))) return false;
    if (layer.merges !== undefined) {
      if (!Array.isArray(layer.merges) || layer.merges.length > 80) return false;
      const rows = layer.rows || 1, cols = layer.cols || 1;
      if (!layer.merges.every(m => m && Number.isInteger(m.r) && Number.isInteger(m.c) && Number.isInteger(m.rowspan) && Number.isInteger(m.colspan) && m.r >= 0 && m.c >= 0 && m.rowspan >= 1 && m.colspan >= 1 && m.r + m.rowspan <= rows && m.c + m.colspan <= cols)) return false;
    }
    if (typeof layer.hidden !== "undefined" && typeof layer.hidden !== "boolean") return false;
    return typeof layer.locked === "undefined" || typeof layer.locked === "boolean";
  });
}
