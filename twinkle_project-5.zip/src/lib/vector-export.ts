/**
 * Vector export engine.
 *
 * Why this exists: the canvas SVG contains SVG filters, masks, image patterns and
 * letter-spaced text — features jsPDF's SVG converter (and most desktop apps)
 * cannot reproduce. Instead of flattening the whole page to a bitmap, this module
 *
 *   1. makes the SVG self-contained (images + uploaded fonts inlined),
 *   2. keeps text, shapes, gradients, photos and clips as real vector artwork,
 *   3. re-renders only the handful of layers that genuinely need browser rendering
 *      (soft shadows, eraser/opacity-fade masks, image fills, outline text) as small
 *      high-resolution patches placed back at the exact layer position,
 *   4. bakes letter-spacing and underlines into real vector glyph runs.
 *
 * The result: a print-ready PDF whose text is selectable and whose curves stay sharp,
 * with effects looking exactly like the canvas.
 */
import type { DesignDocument } from "@/lib/designs";
import { customFonts } from "@/lib/fonts";

const SVG_NS = "http://www.w3.org/2000/svg";
const XLINK_NS = "http://www.w3.org/1999/xlink";

/** Above this many patches a flat page render is faster and just as faithful. */
export const MAX_VECTOR_PATCHES = 40;

export interface Rect { x: number; y: number; width: number; height: number }

/** jsPDF ships metric-compatible replacements for the common web/system fonts. */
const STANDARD_PDF_FONTS: Record<string, string> = {
  arial: "helvetica", helvetica: "helvetica", "helvetica neue": "helvetica", verdana: "helvetica",
  tahoma: "helvetica", "trebuchet ms": "helvetica", "segoe ui": "helvetica", system: "helvetica",
  sans: "helvetica", "sans-serif": "helvetica",
  georgia: "times", "times new roman": "times", times: "times", "book antiqua": "times",
  palatino: "times", "palatino linotype": "times", cambria: "times", garamond: "times", serif: "times",
  "courier new": "courier", courier: "courier", consolas: "courier", menlo: "courier",
  monospace: "courier", mono: "courier",
};

export const cleanFamily = (raw: string | null | undefined): string =>
  (raw || "").split(",")[0].trim().replace(/^['"]|['"]$/g, "");

export const pdfStandardFamily = (family: string): string | null =>
  STANDARD_PDF_FONTS[family.trim().toLowerCase()] ?? null;

const prettyFamily = (family: string) => family.replace(/\+/g, " ").trim();

/* ---------------------------------------------------------------- utilities */

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("This file couldn't be read."));
    reader.readAsDataURL(blob);
  });
}

export function serializeSvg(svg: SVGSVGElement): string {
  return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n${new XMLSerializer().serializeToString(svg)}`;
}

function loadSvgImage(source: string): Promise<{ image: HTMLImageElement; release: () => void }> {
  const blob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const image = new Image();
  image.decoding = "sync";
  return new Promise((resolve, reject) => {
    image.onload = () => resolve({ image, release: () => URL.revokeObjectURL(url) });
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("This artwork couldn't be rendered. Please try again.")); };
    image.src = url;
  });
}

/** Draws a self-contained SVG string onto a canvas at an arbitrary scale. */
export async function renderSvgToCanvas(source: string, width: number, height: number, scale = 1, background?: string): Promise<HTMLCanvasElement> {
  const { image, release } = await loadSvgImage(source);
  try {
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Image export is not supported in this browser.");
    if (background) { context.fillStyle = background; context.fillRect(0, 0, canvas.width, canvas.height); }
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas;
  } finally { release(); }
}

export function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality?: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("Export failed. Please try again.")), type, quality);
  });
}

const iriId = (value: string | null | undefined): string | null => {
  const match = value ? /url\(["']?#([^)"']+)["']?\)/.exec(value) : null;
  return match ? match[1] : null;
};

/* ------------------------------------------------------ self-contained SVG */

async function inlineImages(svg: SVGSVGElement) {
  const nodes = Array.from(svg.querySelectorAll("image"));
  await Promise.all(nodes.map(async node => {
    const href = node.getAttribute("href") || node.getAttributeNS(XLINK_NS, "href") || node.getAttribute("xlink:href");
    if (!href || href.startsWith("data:")) return;
    const response = await fetch(href).catch(() => null);
    if (!response || !response.ok) throw new Error("An image couldn't be included. Please retry.");
    const data = await blobToDataUrl(await response.blob());
    if (node.hasAttributeNS(XLINK_NS, "href")) node.setAttributeNS(XLINK_NS, "xlink:href", data);
    node.setAttribute("href", data);
  }));
}

export function collectFontFamilies(svg: SVGSVGElement): string[] {
  const families = new Set<string>();
  const add = (raw: string | null | undefined) => {
    const name = cleanFamily(raw);
    if (name && name !== "inherit" && !/^(serif|sans-serif|monospace|system-ui)$/i.test(name)) families.add(name);
  };
  svg.querySelectorAll("text, tspan").forEach(node => {
    add(node.getAttribute("font-family"));
    const style = node.getAttribute("style");
    if (style) add(/font-family\s*:\s*([^;]+)/i.exec(style)?.[1]);
  });
  return [...families];
}

/** The family set directly on this node (no inheritance, no default). */
export function ownFamily(node: Element): string {
  const style = node.getAttribute("style");
  const fromStyle = style ? /font-family\s*:\s*([^;]+)/i.exec(style)?.[1] : null;
  return prettyFamily(cleanFamily(fromStyle || node.getAttribute("font-family")));
}

export function familyOf(node: Element): string {
  return ownFamily(node) || "Arial";
}

/**
 * The canvas always writes paint-order="stroke fill" on text, even with no stroke.
 * Only a real stroke can misrender in a vector PDF, so only that forces a patch.
 */
/** True when a node paints with a gradient or pattern (`fill="url(#…)"`). */
export function usesPaintReference(node: Element): boolean {
  const value = (name: string) => {
    const attr = node.getAttribute(name) || "";
    const style = node.getAttribute("style") || "";
    const fromStyle = new RegExp(`${name}\\s*:\\s*([^;]+)`, "i").exec(style)?.[1] || "";
    return (attr + " " + fromStyle).trim();
  };
  return value("fill").startsWith("url(") || value("stroke").startsWith("url(");
}

export function hasRealStroke(node: Element): boolean {
  const stroke = node.getAttribute("stroke");
  if (!stroke || stroke === "none" || stroke === "transparent") return false;
  const raw = node.getAttribute("stroke-width");
  if (raw === null || raw === "") return true;
  return (Number.parseFloat(raw) || 0) > 0;
}

export function fontSizeOf(node: Element): number {
  const raw = node.getAttribute("font-size") || /font-size\s*:\s*([\d.]+)/i.exec(node.getAttribute("style") || "")?.[1];
  const size = Number.parseFloat(String(raw ?? ""));
  return Number.isFinite(size) && size > 0 ? size : 0;
}

/**
 * Fonts used by the artwork: uploaded fonts are embedded as data URLs so the SVG,
 * the PDF patches and raster exports all show the real typeface — even offline.
 */
function fontFaceCss(families: string[]): string {
  const uploaded = new Map(customFonts().map(font => [font.name.toLowerCase(), font]));
  const blocks: string[] = [];
  const imports: string[] = [];
  families.forEach(family => {
    const local = uploaded.get(family.toLowerCase());
    if (local) {
      blocks.push(`@font-face{font-family:'${family}';src:url('${local.dataUrl}');font-display:swap;font-weight:100 900;font-style:normal}`);
      return;
    }
    if (pdfStandardFamily(family)) return; // universal system font
    const query = `family=${encodeURIComponent(family).replace(/%20/g, "+")}:ital,wght@0,400;0,700;1,400`;
    imports.push(`@import url('https://fonts.googleapis.com/css2?${query}&display=swap');`);
  });
  return [...imports, ...blocks].join("\n");
}

export interface PreparedSvg {
  /** Live, on-screen canvas — used for exact on-page geometry. */
  original: SVGSVGElement;
  /** Clean, self-contained clone: no editor chrome, images and fonts inlined. */
  svg: SVGSVGElement;
  source: string;
  families: string[];
}

export async function prepareExportSvg(doc: DesignDocument): Promise<PreparedSvg> {
  const original = document.querySelector<SVGSVGElement>('svg[data-export-canvas="true"]');
  if (!original) throw new Error("Your canvas isn't ready yet.");
  // Vector PDF text is measured from font metrics, so make sure webfonts are ready.
  await document.fonts?.ready.catch(() => undefined);
  const svg = original.cloneNode(true) as SVGSVGElement;
  svg.querySelectorAll("[data-editor-only]").forEach(node => node.remove());
  ["class", "style", "role", "aria-label", "tabindex", "data-export-canvas"].forEach(attr => svg.removeAttribute(attr));
  svg.setAttribute("xmlns", SVG_NS);
  svg.setAttribute("xmlns:xlink", XLINK_NS);
  svg.setAttribute("width", String(doc.width));
  svg.setAttribute("height", String(doc.height));
  svg.setAttribute("viewBox", `0 0 ${doc.width} ${doc.height}`);
  await inlineImages(svg);
  const families = collectFontFamilies(svg);
  const css = fontFaceCss(families);
  if (css) {
    const style = document.createElementNS(SVG_NS, "style");
    style.textContent = css;
    svg.insertBefore(style, svg.firstChild);
  }
  return { original, svg, source: serializeSvg(svg), families };
}

/* ------------------------------------------------------------------- PDF text */

/** Rewrites font-family attributes to jsPDF's metric-compatible base fonts. */
export function applyStandardPdfFonts(svg: SVGSVGElement) {
  svg.querySelectorAll("text, tspan").forEach(node => {
    // Runs without their own family inherit the (already mapped) parent family —
    // writing a default here would silently switch their typeface.
    const own = ownFamily(node);
    if (!own) return;
    const mapped = pdfStandardFamily(own);
    if (!mapped) return;
    node.setAttribute("font-family", mapped);
    const style = node.getAttribute("style");
    if (style) node.setAttribute("style", style.replace(/font-family\s*:\s*[^;]+/i, `font-family:${mapped}`));
  });
}

/**
 * Letter-spacing, underline and strikethrough are ignored by vector PDF writers, so
 * each run is converted into individually positioned glyphs (keeping kerning) and the
 * decorations become real rectangles. Typeset runs carry their tracking on <tspan>
 * children, which are expanded the same way. Layers that cannot be measured are
 * reported so the caller can fall back to a high-resolution patch for them.
 */
export function bakeTextDetails(root: SVGSVGElement): Set<string> {
  const failed = new Set<string>();
  let canvas: HTMLCanvasElement | null = null;
  let context: CanvasRenderingContext2D | null = null;

  const advancesFor = (spec: string, text: string): number[] => {
    if (!canvas) { canvas = document.createElement("canvas"); context = canvas.getContext("2d"); }
    if (!context) throw new Error("no 2d context");
    context.font = spec;
    const advances: number[] = [];
    let previous = 0;
    for (let index = 0; index < text.length; index++) {
      const width = context.measureText(text.slice(0, index + 1)).width;
      advances.push(width - previous);
      previous = width;
    }
    return advances;
  };

  const spacingOf = (node: Element): number => {
    const raw = node.getAttribute("letter-spacing");
    return raw && raw !== "normal" ? Number.parseFloat(raw) || 0 : 0;
  };
  const fail = (node: Element) => {
    const id = node.closest("[data-layer-id]")?.getAttribute("data-layer-id") ?? null;
    if (id) failed.add(id);
  };
  const measureSpec = (family: string, italic: boolean, weight: string, size: number) =>
    `${italic ? "italic " : ""}${weight} ${size}px '${family.replace(/'/g, "")}', sans-serif`;

  /** Copies the paint + font attributes a baked glyph needs to look identical. */
  const paintGlyph = (glyph: SVGTextElement, from: Element, size: number) => {
    ["fill", "stroke", "stroke-width", "stroke-linejoin", "opacity", "style"].forEach(attr => {
      const value = from.getAttribute(attr);
      if (value !== null) glyph.setAttribute(attr, value);
    });
    // paint-order without a real stroke only confuses the patch planner.
    if (hasRealStroke(from)) {
      const order = from.getAttribute("paint-order");
      if (order) glyph.setAttribute("paint-order", order);
    }
    glyph.setAttribute("font-family", familyOf(from));
    glyph.setAttribute("font-size", String(size));
    const weight = from.getAttribute("font-weight");
    if (weight) glyph.setAttribute("font-weight", weight);
    const style = from.getAttribute("font-style");
    if (style) glyph.setAttribute("font-style", style);
  };

  const bars = (into: Element, opts: { x: number; y: number; width: number; size: number; fill: string; underline: boolean; strike: boolean }) => {
    const ink = opts.fill && opts.fill !== "none" && !opts.fill.startsWith("url(") ? opts.fill : null;
    if (!ink) return;
    const thickness = Math.max(1, opts.size * 0.062);
    const bar = (top: number) => {
      const rect = document.createElementNS(SVG_NS, "rect");
      rect.setAttribute("x", String(opts.x));
      rect.setAttribute("y", String(top));
      rect.setAttribute("width", String(Math.max(1, opts.width)));
      rect.setAttribute("height", String(thickness));
      rect.setAttribute("fill", ink);
      into.appendChild(rect);
    };
    if (opts.underline) bar(opts.y + opts.size * 0.1);
    if (opts.strike) bar(opts.y - opts.size * 0.3);
  };

  /* Pass 1 — typeset runs: tracking lives on <tspan> children. Each run becomes
     positioned <text> elements (per glyph when tracked), keeping any transform. */
  for (const text of Array.from(root.querySelectorAll("text"))) {
    const tspans = Array.from(text.children).filter(child => child.tagName.toLowerCase() === "tspan");
    if (!tspans.length) continue;
    const parentSpacing = spacingOf(text);
    const family = familyOf(text);
    const runs = tspans.map(tspan => ({ tspan, spacing: tspan.hasAttribute("letter-spacing") ? spacingOf(tspan) : parentSpacing }));
    if (!runs.some(run => run.spacing)) continue;
    const direct = Array.from(text.childNodes).some(node => node.nodeType === 3 && (node.textContent || "").trim());
    if (direct) { fail(text); continue; }
    try {
      const italic = text.getAttribute("font-style") === "italic";
      const weight = text.getAttribute("font-weight") || "400";
      const fill = text.getAttribute("fill") || "";
      const group = document.createElementNS(SVG_NS, "g");
      const transform = text.getAttribute("transform");
      if (transform) group.setAttribute("transform", transform);
      for (const { tspan, spacing } of runs) {
        const size = fontSizeOf(tspan) || fontSizeOf(text);
        const content = tspan.textContent ?? "";
        if (!size || !content) continue;
        if (content.length > 240) throw new Error("unmeasurable run");
        const x = Number.parseFloat(tspan.getAttribute("x") || "");
        const y = Number.parseFloat(tspan.getAttribute("y") || "");
        if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error("unpositioned run");
        const deco = tspan.getAttribute("text-decoration") || "";
        const holder = document.createElementNS(SVG_NS, "g");
        if (!spacing) {
          const run = document.createElementNS(SVG_NS, "text");
          paintGlyph(run, text, size);
          run.setAttribute("x", String(x));
          run.setAttribute("y", String(y));
          run.setAttribute("text-anchor", "start");
          run.textContent = content;
          holder.appendChild(run);
          bars(holder, { x, y, width: advancesFor(measureSpec(family, italic, weight, size), content).reduce((a, b) => a + b, 0), size, fill, underline: /underline/.test(deco), strike: /line-through/.test(deco) });
        } else {
          const advances = advancesFor(measureSpec(family, italic, weight, size), content);
          let cursor = x;
          for (let index = 0; index < content.length; index++) {
            const advance = advances[index];
            const char = content[index];
            if (char.trim()) {
              const glyph = document.createElementNS(SVG_NS, "text");
              paintGlyph(glyph, text, size);
              glyph.setAttribute("x", String(cursor + advance / 2));
              glyph.setAttribute("y", String(y));
              glyph.setAttribute("text-anchor", "middle");
              glyph.textContent = char;
              holder.appendChild(glyph);
            }
            cursor += advance + spacing;
          }
          bars(holder, { x, y, width: cursor - x, size, fill, underline: /underline/.test(deco), strike: /line-through/.test(deco) });
        }
        group.appendChild(holder);
      }
      text.replaceWith(group);
    } catch { fail(text); }
  }

  /* Pass 2 — plain runs with tracking or decorations. Rotated runs (curve text)
     keep their transform on the wrapping group instead of failing. */
  for (const node of Array.from(root.querySelectorAll("text"))) {
    const spacing = spacingOf(node);
    const deco = node.getAttribute("text-decoration") || "";
    const underline = /underline/.test(deco);
    const strike = /line-through/.test(deco);
    if (!spacing && !underline && !strike) continue;
    if (node.querySelector("tspan")) { fail(node); continue; }
    try {
      const content = node.textContent ?? "";
      const size = fontSizeOf(node);
      if (!size || !content.trim() || content.length > 240) throw new Error("unmeasurable run");
      const family = familyOf(node);
      const italic = node.getAttribute("font-style") === "italic";
      const weight = node.getAttribute("font-weight") || "400";
      const advances = advancesFor(measureSpec(family, italic, weight, size), content);
      const total = advances.reduce((sum, value) => sum + value, 0) + spacing * content.length;
      const x = Number.parseFloat(node.getAttribute("x") || "0") || 0;
      const y = Number.parseFloat(node.getAttribute("y") || "0") || 0;
      const anchor = node.getAttribute("text-anchor");
      const start = anchor === "middle" ? x - total / 2 : anchor === "end" ? x - total : x;
      const fill = node.getAttribute("fill") || "";
      const group = document.createElementNS(SVG_NS, "g");
      const transform = node.getAttribute("transform");
      if (transform) group.setAttribute("transform", transform);

      let cursor = start;
      for (let index = 0; index < content.length; index++) {
        const advance = advances[index];
        const char = content[index];
        if (char.trim()) {
          const glyph = node.cloneNode(false) as SVGTextElement;
          glyph.removeAttribute("letter-spacing");
          glyph.removeAttribute("text-decoration");
          glyph.removeAttribute("transform");
          glyph.setAttribute("x", String(cursor + advance / 2));
          glyph.setAttribute("y", String(y));
          glyph.setAttribute("text-anchor", "middle");
          glyph.textContent = char;
          group.appendChild(glyph);
        }
        cursor += advance + spacing;
      }
      bars(group, { x: start, y, width: total, size, fill, underline, strike });
      node.replaceWith(group);
    } catch { fail(node); }
  }
  return failed;
}

/* ------------------------------------------------------------- patch helpers */

const maxStdDeviation = (value: string | null): number => {
  if (!value) return 0;
  return Math.max(...value.trim().split(/[\s,]+/).map(part => Number.parseFloat(part) || 0));
};

/** Extra room a layer needs so soft shadows, glows and offsets aren't cut off. */
function filterPadding(layer: Element, root: SVGSVGElement): number {
  const id = iriId(layer.getAttribute("filter"));
  if (!id) return 2;
  const filter = Array.from(root.querySelectorAll("filter")).find(node => node.id === id);
  if (!filter) return 8;
  let pad = 0;
  filter.querySelectorAll("feGaussianBlur").forEach(primitive => { pad = Math.max(pad, maxStdDeviation(primitive.getAttribute("stdDeviation")) * 3); });
  filter.querySelectorAll("feDropShadow").forEach(primitive => {
    const blur = maxStdDeviation(primitive.getAttribute("stdDeviation")) * 3;
    pad = Math.max(pad, blur + Math.max(Math.abs(Number(primitive.getAttribute("dx")) || 0), Math.abs(Number(primitive.getAttribute("dy")) || 0)));
  });
  filter.querySelectorAll("feOffset").forEach(primitive => {
    pad = Math.max(pad, Math.max(Math.abs(Number(primitive.getAttribute("dx")) || 0), Math.abs(Number(primitive.getAttribute("dy")) || 0)));
  });
  filter.querySelectorAll("feMorphology").forEach(primitive => { pad = Math.max(pad, (Number.parseFloat(String(primitive.getAttribute("radius") ?? "")) || 0) * 2); });
  filter.querySelectorAll("feDilate, feErode").forEach(primitive => { pad = Math.max(pad, (Number.parseFloat(String(primitive.getAttribute("radius") ?? "")) || 0) * 2); });
  return Math.min(Math.ceil(pad + 8), 400);
}

function imagePatternIds(root: SVGSVGElement): Set<string> {
  const ids = new Set<string>();
  root.querySelectorAll("pattern").forEach(pattern => { if (pattern.querySelector("image")) ids.add(pattern.id); });
  return ids;
}

export interface PatchTarget { id: string; padding: number; reason: string; split: boolean }

/** Behind-the-graphic results the canvas effect builder merges under the artwork. */
const BEHIND_RESULTS = new Set(["shadow", "glow", "outline"]);

/**
 * Shadow, glow and outline effects paint strictly behind the artwork, so only that
 * halo needs a browser render — the content itself can stay vector. True when the
 * layer's filter merges nothing but those behind-layers over an otherwise untouched
 * SourceGraphic (no blur, recolour or contrast work on the graphic itself).
 */
function shadowSplitFilter(layer: Element, root: SVGSVGElement): boolean {
  const id = iriId(layer.getAttribute("filter"));
  if (!id) return false;
  const filter = Array.from(root.querySelectorAll("filter")).find(node => node.id === id);
  if (!filter) return false;
  const merges = Array.from(filter.querySelectorAll("feMergeNode"));
  if (!merges.length) return false;
  let behind = 0;
  for (const merge of merges) {
    const source = merge.getAttribute("in") || "";
    if (BEHIND_RESULTS.has(source)) { behind += 1; continue; }
    if (source === "SourceGraphic") continue;
    return false;
  }
  return behind > 0;
}

/** Drops every feMergeNode except the shadow/glow/outline behind-layers. */
function keepBehindLayersOnly(filter: Element): boolean {
  const merges = Array.from(filter.querySelectorAll("feMergeNode"));
  const behind = merges.filter(merge => BEHIND_RESULTS.has(merge.getAttribute("in") || ""));
  if (!behind.length) return false;
  merges.forEach(merge => { if (!BEHIND_RESULTS.has(merge.getAttribute("in") || "")) merge.remove(); });
  return true;
}

/**
 * Decides which layers must be drawn by the browser. Everything else stays vector.
 */
export function planVectorPatches(root: SVGSVGElement, bakeFailures: Set<string>): PatchTarget[] {
  const patterns = imagePatternIds(root);
  const targets: PatchTarget[] = [];
  root.querySelectorAll("[data-layer-id]").forEach(layer => {
    const id = layer.getAttribute("data-layer-id") || "";
    let reason = "";
    if (layer.hasAttribute("mask")) reason = "mask";
    else if (bakeFailures.has(id)) reason = "decoration";
    if (!reason) {
      // Gradient / pattern paint (on type, shapes, icons, stars, tables…) is drawn by
      // the browser instead: the vector PDF writer drops paint references that sit
      // inside transformed groups, and the artwork silently loses its colour.
      for (const node of Array.from(layer.querySelectorAll("*"))) {
        if (usesPaintReference(node)) { reason = /^(text|tspan)$/i.test(node.tagName) ? "gradient text" : "gradient fill"; break; }
      }
    }
    if (!reason) {
      for (const node of Array.from(layer.querySelectorAll("text"))) {
        // paint-order="stroke fill" is written on every text run; only a real
        // outline stroke can misrender, and only that forces a patch.
        if (node.hasAttribute("paint-order") && hasRealStroke(node)) { reason = "outlined text"; break; }
        const family = familyOf(node);
        // Standard families map to PDF base fonts. Any other family still set on text
        // means its outlines could not be produced (WOFF2 upload, unreadable file).
        if (pdfStandardFamily(family)) continue;
        reason = "custom font"; break;
      }
    }
    if (!reason && patterns.size) {
      for (const node of Array.from(layer.querySelectorAll("[fill],[stroke]"))) {
        const reference = iriId(node.getAttribute("fill")) || iriId(node.getAttribute("stroke"));
        if (reference && patterns.has(reference)) { reason = "image fill"; break; }
      }
    }
    let split = false;
    if (!reason && layer.hasAttribute("filter")) {
      // Content-altering filters (blur, recolour, contrast) need a full patch, but
      // a pure shadow/glow/outline halo is rendered alone beneath vector content.
      reason = "effect";
      split = shadowSplitFilter(layer, root);
    }
    if (reason) targets.push({ id, padding: reason === "mask" ? 6 : filterPadding(layer, root), reason, split });
  });
  // Nested layers: the outer patch already contains the inner one.
  const ids = new Set(targets.map(target => target.id));
  return targets.filter(target => {
    const layer = root.querySelector(`[data-layer-id="${CSS.escape(target.id)}"]`);
    let parent = layer?.parentElement?.closest("[data-layer-id]") ?? null;
    while (parent) { if (ids.has(parent.getAttribute("data-layer-id") || "")) return false; parent = parent.parentElement?.closest("[data-layer-id]") ?? null; }
    return true;
  });
}

interface CropJob { rect: Rect; scale: number }

const patchScale = (rect: Rect) => {
  const wanted = Math.min(4, Math.max(1, Math.round(2800 / Math.max(rect.width, rect.height))));
  // Keep individual patches comfortably inside browser canvas limits.
  const safe = Math.sqrt(24_000_000 / Math.max(1, rect.width * rect.height));
  return Math.max(1, Math.min(wanted, Math.floor(safe * 2) / 2));
};

interface RenderedPatch { href: string; shadowOnly: boolean }

/**
 * Renders one patch. Full patches draw only layers at or below the patched layer, so
 * the patch composites exactly on top of the vector artwork beneath it. Shadow-only
 * patches draw nothing but the layer's own halo over transparency, so the vector
 * content can be painted back on top of them.
 */
async function renderPatch(clean: SVGSVGElement, targetId: string, rect: Rect, scale: number, shadowOnly: boolean): Promise<RenderedPatch> {
  const clone = clean.cloneNode(true) as SVGSVGElement;
  clone.setAttribute("width", String(Math.max(1, Math.round(rect.width * scale))));
  clone.setAttribute("height", String(Math.max(1, Math.round(rect.height * scale))));
  clone.setAttribute("viewBox", `${rect.x} ${rect.y} ${rect.width} ${rect.height}`);
  const layer = Array.from(clone.querySelectorAll("[data-layer-id]")).find(node => node.getAttribute("data-layer-id") === targetId);
  let shadow = false;
  if (shadowOnly && layer) {
    const id = iriId(layer.getAttribute("filter"));
    const filter = id ? Array.from(clone.querySelectorAll("filter")).find(node => node.id === id) : null;
    // The halo alone, without the graphic: vector content is painted over it later.
    shadow = !!filter && keepBehindLayersOnly(filter);
  }
  const skip = new Set(["defs", "style", "title", "metadata", "desc"]);
  let current: Element | null = layer ?? null;
  while (current && current !== clone) {
    // Full patches keep the artwork beneath the layer; shadow patches isolate the
    // layer so sibling pixels never double-blend over the vector art below.
    let sibling = (shadow ? current.parentElement?.firstElementChild : current.nextElementSibling) ?? null;
    while (sibling) {
      if (sibling !== current && !skip.has(sibling.tagName.toLowerCase())) sibling.setAttribute("display", "none");
      sibling = sibling.nextElementSibling;
    }
    current = current.parentElement;
  }
  const canvas = await renderSvgToCanvas(serializeSvg(clone), rect.width, rect.height, scale);
  return { href: canvas.toDataURL("image/png"), shadowOnly: shadow };
}

export interface PatchReport { count: number; reasons: string[] }

/**
 * Patches every flagged layer with a high-resolution render at the same position, so
 * svg2pdf can write the rest of the design as true vector data. Split layers keep
 * their vector content with only the shadow/glow/outline halo placed beneath them.
 */
export async function applyVectorPatches(options: {
  original: SVGSVGElement;
  clean: SVGSVGElement;
  target: SVGSVGElement;
  doc: DesignDocument;
  patches: PatchTarget[];
}): Promise<PatchReport> {
  const { original, clean, target, doc, patches } = options;
  const host = original.getBoundingClientRect();
  const scaleX = host.width ? doc.width / host.width : 1;
  const scaleY = host.height ? doc.height / host.height : 1;
  const live = new Map<string, Element>();
  original.querySelectorAll("[data-layer-id]").forEach(layer => live.set(layer.getAttribute("data-layer-id") || "", layer));
  const reasons: string[] = [];
  let count = 0;

  for (const patch of patches) {
    const node = Array.from(target.querySelectorAll("[data-layer-id]")).find(layer => layer.getAttribute("data-layer-id") === patch.id);
    const source = live.get(patch.id);
    if (!node || !source) continue;
    const box = source.getBoundingClientRect();
    if (!box.width || !box.height) continue;
    const pad = patch.padding;
    const x = Math.max(0, (box.left - host.left) * scaleX - pad);
    const y = Math.max(0, (box.top - host.top) * scaleY - pad);
    const right = Math.min(doc.width, (box.right - host.left) * scaleX + pad);
    const bottom = Math.min(doc.height, (box.bottom - host.top) * scaleY + pad);
    const rect: Rect = { x, y, width: right - x, height: bottom - y };
    if (rect.width < 2 || rect.height < 2) continue;
    try {
      const rendered = await renderPatch(clean, patch.id, rect, patchScale(rect), patch.split);
      const image = document.createElementNS(SVG_NS, "image");
      image.setAttribute("href", rendered.href);
      image.setAttribute("x", String(rect.x));
      image.setAttribute("y", String(rect.y));
      image.setAttribute("width", String(rect.width));
      image.setAttribute("height", String(rect.height));
      image.setAttribute("preserveAspectRatio", "none");
      if (patch.split && rendered.shadowOnly) {
        node.removeAttribute("filter");
        node.before(image);
      } else {
        node.replaceWith(image);
      }
      count += 1;
      if (!reasons.includes(patch.reason)) reasons.push(patch.reason);
    } catch { /* the layer stays vector from the flat fallback below */ }
  }
  return { count, reasons };
}
