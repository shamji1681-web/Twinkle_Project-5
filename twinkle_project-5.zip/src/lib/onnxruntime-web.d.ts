// ONNX Runtime 1.21's WASM subpath does not expose its types under bundler resolution.
declare module "onnxruntime-web/wasm" {
  export { env, InferenceSession, Tensor } from "onnxruntime-common";
}