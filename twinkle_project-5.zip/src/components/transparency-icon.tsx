import type { SVGProps } from "react";

/** Transparency checkerboard glyph — the standard editor icon for opacity. */
export default function TransparencyIcon({ size = 16, ...props }: SVGProps<SVGSVGElement> & { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
      {/* Rounded transparent-plate outline */}
      <path
        d="M7 2.8h10c2.3 0 4.2 1.9 4.2 4.2v10c0 2.3-1.9 4.2-4.2 4.2H7c-2.3 0-4.2-1.9-4.2-4.2V7C2.8 4.7 4.7 2.8 7 2.8Z"
        stroke="currentColor"
        strokeWidth="1.7"
      />
      {/* Checkerboard: solid cells drawn, gaps stay transparent */}
      <g fill="currentColor">
        <path d="M6.6 6.6h3.6v3.6H6.6z" />
        <path d="M13.8 6.6h3.6v3.6h-3.6z" />
        <path d="M10.2 10.2h3.6v3.6h-3.6z" />
        <path d="M6.6 13.8h3.6v3.6H6.6z" />
        <path d="M13.8 13.8h3.6v3.6h-3.6z" />
      </g>
    </svg>
  );
}
