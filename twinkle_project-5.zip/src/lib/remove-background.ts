import { resolveAsset } from "./asset-map";
import { segmentSubject } from "./background-removal.engine";
import type { BackgroundRemovalProgress } from "./background-removal.types";

export type { BackgroundRemovalProgress } from "./background-removal.types";

interface RemovalOptions {
  signal?: AbortSignal;
  onProgress?: (progress: BackgroundRemovalProgress) => void;
}

const MAX_SIDE = 2048;
const MAX_PNG_BYTES = 2_950_000;
let busy = false;

function checkCancelled(signal?: AbortSignal) {
  if (signal?.aborted) throw new DOMException("Background removal cancelled.", "AbortError");
}

function loadImage(src: string, signal?: AbortSignal): Promise<HTMLImageElement> {
  checkCancelled(signal);
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    const cleanup = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      image.onload = null;
      image.onerror = null;
    };
    const abort = () => {
      cleanup();
      image.src = "";
      reject(new DOMException("Background removal cancelled.", "AbortError"));
    };
    const timer = setTimeout(() => {
      cleanup();
      image.src = "";
      reject(new Error("The photo took too long to load. Try uploading it again."));
    }, 30_000);
    image.onload = () => {
      cleanup();
      if (!image.naturalWidth || !image.naturalHeight) reject(new Error("This image has no readable pixels."));
      else resolve(image);
    };
    image.onerror = () => {
      cleanup();
      reject(new Error("This photo could not be loaded. Try a PNG, JPG or WebP upload."));
    };
    signal?.addEventListener("abort", abort, { once: true });
    image.src = resolveAsset(src);
  });
}

async function segment(image: Blob, options: RemovalOptions): Promise<Blob> {
  checkCancelled(options.signal);
  let timedOut = false;
  const onAbort = () => {
    checkCancelled(options.signal);
  };
  options.signal?.addEventListener("abort", onAbort, { once: true });
  const timer = setTimeout(() => {
    timedOut = true;
  }, 240_000);
  try {
    const result = await segmentSubject(image, progress => {
      if (timedOut) return;
      options.onProgress?.(progress);
    });
    if (timedOut) throw new Error("AI processing timed out. Check your connection and try a smaller photo.");
    checkCancelled(options.signal);
    return result;
  } catch (error) {
    if (timedOut) throw new Error("AI processing timed out. Check your connection and try a smaller photo.");
    const message = error instanceof Error ? error.message : String(error);
    const network = /fetch|network|download|resource|publicpath|load/i.test(message);
    throw new Error(network
      ? "The AI model could not load. The first use needs an internet connection; check your connection and retry."
      : error instanceof DOMException && error.name === "AbortError"
        ? message
        : "AI background removal could not finish on this device. Try a smaller photo or an updated browser.");
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", onAbort);
  }
}

function pngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("The transparent PNG could not be created.")), "image/png");
  });
}

async function storablePng(canvas: HTMLCanvasElement, signal?: AbortSignal): Promise<string> {
  let output = await pngBlob(canvas);
  let ratio = 1;
  // Keep PNG transparency within the document's 4 MB data-URL limit.
  while (output.size > MAX_PNG_BYTES && ratio > 0.25) {
    checkCancelled(signal);
    ratio *= 0.8;
    const smaller = document.createElement("canvas");
    smaller.width = Math.max(1, Math.round(canvas.width * ratio));
    smaller.height = Math.max(1, Math.round(canvas.height * ratio));
    const context = smaller.getContext("2d");
    if (!context) throw new Error("Canvas is not available in this browser.");
    context.imageSmoothingQuality = "high";
    context.drawImage(canvas, 0, 0, smaller.width, smaller.height);
    output = await pngBlob(smaller);
    smaller.width = smaller.height = 0;
  }
  if (output.size > MAX_PNG_BYTES) throw new Error("The result is too large to save. Try a smaller photo.");
  checkCancelled(signal);
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("The transparent PNG could not be read."));
    reader.readAsDataURL(output);
  });
}

/** Subject segmentation, not colour erasure. Images stay local; only model assets are downloaded. */
export async function removeBackgroundInBrowser(src: string, options: RemovalOptions = {}): Promise<string> {
  if (!src) throw new Error("Select a photo first.");
  if (busy) throw new Error("Another background removal is still running. Please wait.");
  checkCancelled(options.signal);
  busy = true;
  let canvas: HTMLCanvasElement | undefined;
  try {
    if (typeof WebAssembly === "undefined") {
      throw new Error("AI background removal needs a browser with WebAssembly support.");
    }
    options.onProgress?.({ stage: "preparing", message: "Preparing the photo" });
    const image = await loadImage(src, options.signal);
    checkCancelled(options.signal);
    const ratio = Math.min(1, MAX_SIDE / Math.max(image.naturalWidth, image.naturalHeight));
    canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * ratio));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * ratio));
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) throw new Error("Canvas is not available in this browser.");
    context.imageSmoothingQuality = "high";
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    let original: ImageData;
    try { original = context.getImageData(0, 0, canvas.width, canvas.height); }
    catch { throw new Error("This photo blocks pixel access. Upload a local copy, then try Remove BG again."); }

    // Flatten only the inference input. Preserve original RGB and alpha in the result.
    const input = new Uint8Array(original.data.length);
    for (let i = 0; i < input.length; i += 4) {
      const alpha = original.data[i + 3] / 255;
      for (let channel = 0; channel < 3; channel++) input[i + channel] = Math.round(original.data[i + channel] * alpha + 255 * (1 - alpha));
      input[i + 3] = 255;
    }
    const source = new Blob([input], { type: `image/x-rgba8;width=${canvas.width};height=${canvas.height}` });
    options.onProgress?.({ stage: "loading", message: "Preparing AI (first use downloads the model)" });
    const result = await segment(source, options);
    checkCancelled(options.signal);
    options.onProgress?.({ stage: "refining", message: "Preserving transparent edges" });
    const pixels = new Uint8Array(await result.arrayBuffer());
    if (pixels.length !== original.data.length) throw new Error("The AI result has unexpected dimensions. Please retry.");

    let sourceAlpha = 0, keptAlpha = 0;
    for (let i = 3; i < pixels.length; i += 4) {
      const alpha = original.data[i];
      sourceAlpha += alpha;
      original.data[i] = Math.round(alpha * pixels[i] / 255);
      keptAlpha += original.data[i];
    }
    if (keptAlpha < Math.max(255, sourceAlpha * 0.0001)) {
      throw new Error("No clear subject was detected. Your original is unchanged; try a photo with a distinct person or object.");
    }
    if (sourceAlpha - keptAlpha < sourceAlpha * 0.0001) {
      throw new Error("No separate background was detected. Your original photo has been kept.");
    }
    context.putImageData(original, 0, 0);
    options.onProgress?.({ stage: "encoding", message: "Creating transparent PNG" });
    const dataUrl = await storablePng(canvas, options.signal);
    checkCancelled(options.signal);
    return dataUrl;
  } finally {
    busy = false;
    if (canvas) canvas.width = canvas.height = 0;
  }
}
