import { useRef, type PointerEvent } from "react";
import type { DesignLayer } from "@/lib/designs";
import { cropPanFromDelta } from "@/components/table-overlay";

interface Props {
  layer: DesignLayer;
  scale: number;
  onChange: (updates: Partial<DesignLayer>) => void;
  onStart: () => void;
  onEnd: () => void;
}

export default function CropOverlay({ layer, scale, onChange, onStart, onEnd }: Props) {
  const drag = useRef<{ x: number; y: number; cropX: number; cropY: number } | null>(null);
  const zoom = Math.max(1, layer.cropZoom || 1);

  function begin(event: PointerEvent<HTMLDivElement>) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    onStart();
    drag.current = { x: event.clientX, y: event.clientY, cropX: layer.cropX || 0, cropY: layer.cropY || 0 };
  }
  function move(event: PointerEvent<HTMLDivElement>) {
    if (!drag.current) return;
    const next = cropPanFromDelta({ ...layer, cropX: drag.current.cropX, cropY: drag.current.cropY }, (event.clientX - drag.current.x) / scale, (event.clientY - drag.current.y) / scale);
    onChange(next);
  }
  function finish(event: PointerEvent<HTMLDivElement>) {
    if (!drag.current) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    drag.current = null;
    onEnd();
  }

  return <div
    className="crop-overlay"
    style={{ left: layer.x * scale, top: layer.y * scale, width: layer.width * scale, height: layer.height * scale, transform: `rotate(${layer.rotation || 0}deg)` }}
    onPointerDown={begin}
    onPointerMove={move}
    onPointerUp={finish}
    onPointerCancel={finish}
    role="slider"
    aria-label="Drag to pan the crop"
    aria-valuemin={1}
    aria-valuemax={4}
    aria-valuenow={zoom}
  >
    <span className="crop-hint">Drag to pan · use the zoom slider in the topbar</span>
  </div>;
}
