import { useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { createPortal } from "react-dom";
import { ArrowDown, ArrowDownToLine, ArrowLeftRight, ArrowUp, ArrowUpDown, ArrowUpToLine, Combine, Copy, Crop, FlipHorizontal2, FlipVertical2, Grid2X2, Layers, LockKeyhole, Pencil, QrCode, Trash2, Type, UnlockKeyhole, Wand2 } from "lucide-react";
import type { DesignLayer } from "@/lib/designs";
import { mergeAt, tableSize } from "@/lib/table";
import type { EditorContext } from "@/components/editor-panels";

interface Props { ctx: EditorContext; layer: DesignLayer; scale: number; paperRef: RefObject<HTMLDivElement | null>; stageRef: RefObject<HTMLDivElement | null> }
const names: Record<string, string> = { text: "Text", image: "Image", table: "Table", icon: "Icon", shape: "Shape", draw: "Drawing", stroke: "Line", line: "Line", rect: "Shape", ellipse: "Shape", star: "Shape", flower: "Shape", pattern: "Pattern" };

export default function ObjectToolbar({ ctx, layer, scale, paperRef, stageRef }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<{ left: number; top: number; maxWidth: number; visible: boolean } | null>(null);
  const [arrange, setArrange] = useState(false);
  const isTable = layer.type === "table";
  const size = tableSize(layer);
  const cell = ctx.selectedCells[0];
  const canSplit = isTable && cell && !!mergeAt(layer, cell.r, cell.c);
  const locked = !!layer.locked;

  useLayoutEffect(() => {
    let frame = 0;
    function update() {
      if (!paperRef.current || !stageRef.current) return;
      const paper = paperRef.current.getBoundingClientRect(), stage = stageRef.current.getBoundingClientRect();
      const actualScale = scale;
      const a = (layer.rotation || 0) * Math.PI / 180;
      const w = (Math.abs(Math.cos(a)) * layer.width + Math.abs(Math.sin(a)) * layer.height) * actualScale;
      const h = (Math.abs(Math.sin(a)) * layer.width + Math.abs(Math.cos(a)) * layer.height) * actualScale;
      const cx = paper.left + (layer.x + layer.width / 2) * actualScale, cy = paper.top + (layer.y + layer.height / 2) * actualScale;
      const loX = Math.max(8, stage.left + 8), hiX = Math.min(window.innerWidth - 8, stage.right - 8);
      const loY = Math.max(stage.top + 8, 8), hiY = Math.min(stage.bottom - 8, window.innerHeight - 8);
      const maxWidth = Math.max(180, hiX - loX);
      const toolbarWidth = Math.min(ref.current?.offsetWidth || 320, maxWidth), toolbarHeight = ref.current?.offsetHeight || 43;
      let top = cy - h / 2 - toolbarHeight - 47;
      if (top < loY) top = cy + h / 2 + 18;
      top = Math.max(loY, Math.min(top, hiY - toolbarHeight));
      const next = { left: Math.max(loX, Math.min(cx - toolbarWidth / 2, hiX - toolbarWidth)), top, maxWidth, visible: cx + w / 2 >= loX && cx - w / 2 <= hiX && cy + h / 2 >= loY && cy - h / 2 <= hiY };
      setPosition(previous => previous && Math.abs(previous.left - next.left) < .25 && Math.abs(previous.top - next.top) < .25 && previous.maxWidth === next.maxWidth && previous.visible === next.visible ? previous : next);
    }
    function schedule() { cancelAnimationFrame(frame); frame = requestAnimationFrame(update); }
    update();
    const observer = new ResizeObserver(schedule);
    if (ref.current) observer.observe(ref.current);
    if (paperRef.current) observer.observe(paperRef.current);
    if (stageRef.current) observer.observe(stageRef.current);
    document.addEventListener('scroll', schedule, true); window.addEventListener('resize', schedule);
    return () => { cancelAnimationFrame(frame); observer.disconnect(); document.removeEventListener('scroll', schedule, true); window.removeEventListener('resize', schedule); };
  }, [layer.x, layer.y, layer.width, layer.height, layer.rotation, scale, paperRef, stageRef, arrange, locked, ctx.selectedCells.length]);

  useLayoutEffect(() => {
    if (!arrange) return;
    const outside = (event: PointerEvent) => { if (!(event.target as Element).closest('[data-floating-arrange]')) setArrange(false); };
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') { event.stopImmediatePropagation(); setArrange(false); } };
    document.addEventListener('pointerdown', outside, true); document.addEventListener('keydown', escape, true);
    return () => { document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', escape, true); };
  }, [arrange]);

  const action = (label: string, content: ReactNode, onClick: () => void, disabled = false, pressed?: boolean, extra = "") => <button type="button" className={`object-action ${extra}`} aria-label={label} title={label} disabled={disabled} aria-pressed={pressed} onClick={onClick}>{content}</button>;
  const flip = (axis: "flipX" | "flipY") => ctx.patch(layer.id, { effects: { ...layer.effects, [axis]: !layer.effects?.[axis] } });
  const separator = <span className="object-toolbar-divider" />;

  return createPortal(<div ref={ref} className={`object-toolbar ${isTable ? "for-table" : ""}`} data-object-toolbar="true" data-editor-only="true" role="toolbar" aria-label={`${names[layer.type] || "Object"} floating toolbar`} style={{ left: position?.left || 0, top: position?.top || 0, maxWidth: position?.maxWidth || 360, visibility: position?.visible ? "visible" : "hidden" }}>
    {action("Duplicate object", <Copy size={16} />, () => ctx.duplicate(layer.id), ctx.full)}
    {!locked && <>
      {isTable ? <>
        {action("Distribute table columns evenly", <ArrowLeftRight size={16} />, () => ctx.tableDistribute("column"), size.cols < 2)}
        {action("Distribute table rows evenly", <ArrowUpDown size={16} />, () => ctx.tableDistribute("row"), size.rows < 2)}
        {separator}
        {action("Delete selected table row", <><Trash2 size={14} /><span>Row</span></>, () => ctx.tableDelete("row"), size.rows <= 1)}
        {action("Delete selected table column", <><Trash2 size={14} /><span>Col</span></>, () => ctx.tableDelete("column"), size.cols <= 1)}
        {ctx.selectedCells.length > 1 && action("Merge selected table cells", <Combine size={16} />, ctx.mergeSelected)}
        {canSplit && action("Split selected table cells", <Grid2X2 size={16} />, ctx.splitSelected)}
        {separator}
        <button className={`object-action ${ctx.tableStyleOpen ? "active" : ""}`} type="button" data-table-style-trigger aria-label="Style table borders" title="Borders & fill" onClick={() => ctx.setTableStyleOpen(!ctx.tableStyleOpen)}><Grid2X2 size={16} /></button>
      </> : <>
        {action("Flip object horizontally", <FlipHorizontal2 size={16} />, () => flip("flipX"), false, !!layer.effects?.flipX)}
        {action("Flip object vertically", <FlipVertical2 size={16} />, () => flip("flipY"), false, !!layer.effects?.flipY)}
        {separator}
        {layer.type === "text" && action("Edit object text", <><Type size={15} /><span>Edit</span></>, () => ctx.startEditing(layer.id))}
        {layer.type === "image" && !layer.qr && action("Crop selected image", <><Crop size={16} /><span>Crop</span></>, () => ctx.setCropMode(true))}
        {layer.qr && action("Edit selected QR code", <><QrCode size={16} /><span>QR</span></>, () => ctx.openPanel("qr"))}
        {layer.type === "draw" && action("Open drawing tools", <Pencil size={16} />, () => ctx.openPanel("draw"))}
        {action("Object effects", <Wand2 size={16} />, () => ctx.openPanel("effects"))}
      </>}
    </>}
    {separator}
    <div className="object-arrange-wrap" data-floating-arrange>
      {action("Arrange object layers", <Layers size={16} />, () => setArrange(!arrange), false, arrange)}
      {arrange && <div className={`object-arrange-menu ${position && position.top > window.innerHeight - 235 ? "open-up" : ""}`} role="group" aria-label="Arrange selected object">{([
        ["front", "Bring to front", ArrowUpToLine], ["up", "Bring forward", ArrowUp], ["down", "Send backward", ArrowDown], ["back", "Send to back", ArrowDownToLine],
      ] as const).map(([direction, label, Icon]) => <button key={direction} type="button" onClick={() => { ctx.reorder(layer.id, direction); setArrange(false); }}><Icon size={14} />{label}</button>)}</div>}
    </div>
    {action(locked ? "Unlock selected object" : "Lock selected object", locked ? <LockKeyhole size={15} /> : <UnlockKeyhole size={15} />, () => ctx.patch(layer.id, { locked: !locked }), false, locked)}
    {action("Delete object", <Trash2 size={15} />, () => ctx.remove(layer.id), false, undefined, "object-delete")}
  </div>, document.body);
}
