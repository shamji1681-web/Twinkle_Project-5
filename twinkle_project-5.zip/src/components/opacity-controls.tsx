import { ArrowDown, ArrowLeft, ArrowLeftRight, ArrowRight, ArrowUp, Blend, Check, MousePointer2, RotateCcw, X } from "lucide-react";
import type { DesignLayer } from "@/lib/designs";
import { defaultOpacityFade, fadeAngle, rotateOpacityFade, type FadeDirection, type OpacityFade } from "@/lib/opacity-fade";
import DesignCanvas from "@/components/design-canvas";
import RangeControl from "@/components/range-control";

interface Props {
  layer: DesignLayer;
  editing: boolean;
  onPatch: (updates: Partial<DesignLayer>) => void;
  onEditingChange: (editing: boolean) => void;
  onClose: () => void;
}

const directions = [
  { id: "right", name: "Fade right", icon: ArrowRight },
  { id: "left", name: "Fade left", icon: ArrowLeft },
  { id: "down", name: "Fade down", icon: ArrowDown },
  { id: "up", name: "Fade up", icon: ArrowUp },
] as const;

export default function OpacityControls({ layer, editing, onPatch, onEditingChange, onClose }: Props) {
  const fade = layer.opacityFade;
  const preview = { ...layer, id: "opacity-preview", x: 0, y: 0, rotation: 0, hidden: false, opacityFade: fade || defaultOpacityFade() };
  const angle = fade ? fadeAngle(fade, layer) : 0;
  const matches = (direction: FadeDirection) => {
    if (!fade) return false;
    const example = defaultOpacityFade(direction);
    return ["start", "end"].every(key => {
      const p = key as "start" | "end";
      return Math.abs(example[p].x - fade[p].x) < .001 && Math.abs(example[p].y - fade[p].y) < .001;
    });
  };
  function changeFade(updates: Partial<OpacityFade>) { onPatch({ opacityFade: { ...(fade || defaultOpacityFade()), ...updates } }); }
  function enable() { onPatch({ opacityFade: defaultOpacityFade() }); onEditingChange(true); }
  function remove() { onPatch({ opacityFade: undefined }); onEditingChange(false); }
  return <section className="opacity-controls" aria-label="Opacity and fade">
    <div className="opacity-controls-heading"><span><Blend size={16} /><strong>Opacity</strong></span><button className="icon-button" aria-label="Close opacity settings" onClick={onClose}><X size={16} /></button></div>
    <label className="fade-slider-label" htmlFor={`opacity-${layer.id}`}>Whole element <span>{Math.round((layer.opacity ?? 1) * 100)}%</span></label>
    <RangeControl label="Opacity slider" hideLabel min={0} max={100} value={(layer.opacity ?? 1) * 100} unit="%" onChange={v => onPatch({ opacity: v / 100 })} />
    <div className="context-quick">{[100, 75, 50, 25, 10].map(pct => <button key={pct} className={Math.round((layer.opacity ?? 1) * 100) === pct ? "active" : ""} aria-label={`Set opacity to ${pct}%`} onClick={() => onPatch({ opacity: pct / 100 })}>{pct}%</button>)}</div>

    <div className="fade-section-heading"><div><strong>Opacity fade</strong><small>One side visible. One side transparent.</small></div><button className={`fade-switch ${fade ? "is-on" : ""}`} role="switch" aria-checked={!!fade} aria-label="Enable opacity fade" onClick={fade ? remove : enable}><span /></button></div>
    <div className="opacity-fade-preview" aria-label="Fade preview on a transparent background"><DesignCanvas document={{ width: layer.width, height: layer.height, background: "transparent", layers: [preview] }} /></div>
    {!fade ? <>
      <p className="fade-help">Fade into the background—not a white overlay. Works with photos, text and every shape.</p>
      <button className="primary-button full-width" onClick={enable}><Blend size={15} />Add opacity fade</button>
    </> : <>
      <div className="fade-direction-row" role="group" aria-label="Fade direction">{directions.map(({ id, name, icon: Icon }) => <button key={id} title={name} aria-label={name} aria-pressed={matches(id)} className={matches(id) ? "active" : ""} onClick={() => { onPatch({ opacityFade: { ...defaultOpacityFade(id), startOpacity: fade.startOpacity, endOpacity: fade.endOpacity, midpoint: fade.midpoint } }); }}><Icon size={17} /></button>)}<button title="Reverse opacity" aria-label="Reverse opacity fade" onClick={() => changeFade({ startOpacity: fade.endOpacity, endOpacity: fade.startOpacity })}><ArrowLeftRight size={17} /></button></div>
      <div className="fade-end-values">
        <label><span><i className="fade-start-dot" />Start opacity</span><div><input type="number" aria-label="Fade start opacity" min={0} max={100} value={Math.round(fade.startOpacity * 100)} onChange={e => changeFade({ startOpacity: Math.min(100, Math.max(0, Number(e.target.value))) / 100 })} /><small>%</small></div></label>
        <label><span><i className="fade-end-dot" />End opacity</span><div><input type="number" aria-label="Fade end opacity" min={0} max={100} value={Math.round(fade.endOpacity * 100)} onChange={e => changeFade({ endOpacity: Math.min(100, Math.max(0, Number(e.target.value))) / 100 })} /><small>%</small></div></label>
      </div>
      <label className="fade-slider-label" htmlFor={`fade-mid-${layer.id}`}>Transition midpoint <span>{Math.round(fade.midpoint * 100)}%</span></label>
      <RangeControl label="Fade transition midpoint" hideLabel min={5} max={95} value={Math.round(fade.midpoint * 100)} unit="%" onChange={v => changeFade({ midpoint: v / 100 })} />
      <RangeControl label="Fade angle" min={0} max={359} value={angle} unit="°" onChange={v => onPatch({ opacityFade: rotateOpacityFade(fade, v, layer) })} />
      <button className={`fade-edit-button ${editing ? "is-editing" : ""}`} aria-pressed={editing} aria-label={editing ? "Finish adjusting fade" : "Adjust fade on canvas"} disabled={!!layer.locked || !!layer.hidden} onClick={() => { onEditingChange(!editing); if (!editing) onClose(); }}>{editing ? <Check size={16} /> : <MousePointer2 size={16} />}{editing ? "Done adjusting" : "Adjust on canvas"}</button>
      <p className="fade-help">Drag the square and arrow to set the fade range. Use the round handle to rotate; the centre marker changes the transition.</p>
      {layer.qr && <p className="fade-qr-note">Fading a QR code can affect scanning. Test it before sharing.</p>}
      <div className="fade-footer"><button onClick={() => onPatch({ opacityFade: defaultOpacityFade() })}><RotateCcw size={13} />Reset fade</button><button onClick={remove}><X size={13} />Remove fade</button></div>
    </>}
  </section>;
}
