import { useSyncExternalStore } from "react";

export type Theme = "light" | "dark";

const KEY = "creato-theme";
const listeners = new Set<() => void>();

function read(): Theme {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved === "light" || saved === "dark") return saved;
  } catch { /* Private browsing: fall through to the system preference. */ }
  try {
    if (window.matchMedia?.("(prefers-color-scheme: dark)").matches) return "dark";
  } catch { /* Older browsers: stay light. */ }
  return "light";
}

let current: Theme = typeof document === "undefined" ? "light" : read();

function apply() {
  try { document.documentElement.dataset.theme = current; } catch { /* No DOM yet. */ }
}

if (typeof document !== "undefined") apply();

export function getTheme(): Theme { return current; }

export function setTheme(next: Theme) {
  if (current === next) return;
  current = next;
  try { localStorage.setItem(KEY, next); } catch { /* Ignore storage failures. */ }
  apply();
  listeners.forEach(fn => fn());
}

export function toggleTheme() { setTheme(current === "dark" ? "light" : "dark"); }

function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

/** Reactive theme shared by the dashboard and editor headers. */
export function useTheme(): Theme {
  return useSyncExternalStore(subscribe, getTheme, getTheme);
}
