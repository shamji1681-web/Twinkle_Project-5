import { useRef, type PointerEvent, type MouseEvent } from "react";
import { Plus } from "lucide-react";
import TableCellTextEditor from "@/components/table-cell-text-editor";
import type { DesignLayer } from "@/lib/designs";
import { cellSpan, cellsInRect, mergeAt, tableCellFill, tableCellBackground, tableCellTextColor, tableFractions, tableTracks, type CellRef } from "@/lib/table";

interface Props {
  layer: DesignLayer;
  scale: number;
  selected: CellRef[];
  editing: CellRef | null;
  onSelect: (cell: CellRef, additive: boolean) => void;
  onSelectRange: (cells: CellRef[]) => void;
  onEdit: (cell: CellRef) => void;
  onTracks: (updates: { colWidths?: number[]; rowHeights?: number[] }) => void;
  onStart: () => void;
  onEnd: () => void;
  onCellText: (r: number, c: number, text: string) => void;
  onCommitEdit: () => void;
  onInsert: (axis: "row" | "column") => void;
}

export default function TableOverlay({ layer, scale, selected, editing, onSelect, onSelectRange, onEdit, onTracks, onStart, onEnd, onCellText, onCommitEdit, onInsert }: Props) {
  const drag = useRef<{ kind: "col" | "row"; index: number; x: number; y: number; widths: number[]; heights: number[]; angle: number; scale: number } | null>(null);
  const { rows, cols, xs, ys } = tableTracks(layer);
  const activeCell = (r: number, c: number) => selected.some(cell => {
    const origin = mergeAt(layer, cell.r, cell.c) || { ...cell, rowspan: 1, colspan: 1 };
    return r >= origin.r && r < origin.r + origin.rowspan && c >= origin.c && c < origin.c + origin.colspan;
  });
  function beginLine(event: PointerEvent<HTMLButtonElement>, kind: "col" | "row", index: number) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    onStart();
    drag.current = { kind, index, x: event.clientX, y: event.clientY, widths: tableFractions(layer, "column"), heights: tableFractions(layer, "row"), angle: -(layer.rotation || 0) * Math.PI / 180, scale };
  }
  function moveLine(event: PointerEvent<HTMLButtonElement>) {
    const d = drag.current;
    if (!d) return;
    const dx = (event.clientX - d.x) / d.scale, dy = (event.clientY - d.y) / d.scale;
    const localX = dx * Math.cos(d.angle) - dy * Math.sin(d.angle), localY = dx * Math.sin(d.angle) + dy * Math.cos(d.angle);
    const delta = (d.kind === "col" ? localX : localY) / (d.kind === "col" ? layer.width : layer.height);
    const list = [...(d.kind === "col" ? d.widths : d.heights)], i = d.index;
    const total = list[i] + list[i + 1];
    list[i] = Math.max(.02, Math.min(total - .02, list[i] + delta)); list[i + 1] = total - list[i];
    onTracks(d.kind === "col" ? { colWidths: list } : { rowHeights: list });
  }
  function endLine(event: PointerEvent<HTMLButtonElement>) {
    if (!drag.current) return;
    drag.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    onEnd();
  }
  function selectCell(event: MouseEvent<HTMLDivElement>, cell: CellRef) { event.stopPropagation(); if (!(event.target as Element).closest('textarea')) onSelect(cell, event.shiftKey || event.ctrlKey || event.metaKey); }
  return <div className="table-overlay" data-table-ui style={{ left: layer.x * scale, top: layer.y * scale, width: layer.width * scale, height: layer.height * scale, transform: `rotate(${layer.rotation || 0}deg)` }} role="grid" aria-label="Editable table" aria-rowcount={rows} aria-colcount={cols}>
    {Array.from({ length: rows }, (_, r) => Array.from({ length: cols }, (_, c) => {
      const m = mergeAt(layer, r, c);
      if (m && (m.r !== r || m.c !== c)) return null;
      const span = cellSpan(layer, r, c);
      const x = xs[c], y = ys[r], w = xs[c + span.colspan] - xs[c], h = ys[r + span.rowspan] - ys[r];
      const isEditing = editing?.r === r && editing?.c === c;
      return <div key={`${r}-${c}`} className={`table-cell ${activeCell(r, c) ? "is-selected" : ""}`} style={{ left: x * scale, top: y * scale, width: w * scale, height: h * scale }} role="gridcell" tabIndex={0} aria-selected={activeCell(r, c)} aria-label={`Cell row ${r + 1} column ${c + 1}`} aria-rowindex={r + 1} aria-colindex={c + 1} onPointerDown={e => e.stopPropagation()} onClick={e => selectCell(e, { r, c })} onDoubleClick={e => { e.stopPropagation(); if (!isEditing) onEdit({ r, c }); }} onKeyDown={e => { if (e.target !== e.currentTarget) return; if (e.key === "Enter" || e.key === "F2") { e.preventDefault(); e.stopPropagation(); onEdit({ r, c }); } if (e.key === " ") { e.preventDefault(); onSelect({ r, c }, e.shiftKey); } }}>
        {isEditing && <TableCellTextEditor layer={layer} r={r} c={c} width={w} height={h} scale={scale} onChange={text => onCellText(r, c, text)} onCommit={onCommitEdit} onStart={onStart} onEnd={onEnd} />}
      </div>;
    }))}
    {xs.slice(1, -1).map((x, i) => <button key={`v${i}`} type="button" className="table-rule table-rule-v" style={{ left: x * scale }} aria-label={`Resize column ${i + 1}`} onPointerDown={e => beginLine(e, "col", i)} onPointerMove={moveLine} onPointerUp={endLine} onPointerCancel={endLine} />)}
    {ys.slice(1, -1).map((y, i) => <button key={`h${i}`} type="button" className="table-rule table-rule-h" style={{ top: y * scale }} aria-label={`Resize row ${i + 1}`} onPointerDown={e => beginLine(e, "row", i)} onPointerMove={moveLine} onPointerUp={endLine} onPointerCancel={endLine} />)}
    {Array.from({ length: cols }, (_, c) => <button key={`col${c}`} className="table-select-track table-select-col" style={{ left: (xs[c] + xs[c + 1]) / 2 * scale }} aria-label={`Select column ${c + 1}`} title={`Select column ${c + 1}`} onClick={e => { e.stopPropagation(); onSelectRange(cellsInRect(0, c, rows - 1, c)); }}>{c + 1}</button>)}
    {Array.from({ length: rows }, (_, r) => <button key={`row${r}`} className="table-select-track table-select-row" style={{ top: (ys[r] + ys[r + 1]) / 2 * scale }} aria-label={`Select row ${r + 1}`} title={`Select row ${r + 1}`} onClick={e => { e.stopPropagation(); onSelectRange(cellsInRect(r, 0, r, cols - 1)); }}>{r + 1}</button>)}
    <button className="table-add-handle table-add-column" aria-label="Add column at table edge" title="Add column" disabled={cols >= 12} onClick={e => { e.stopPropagation(); onInsert("column"); }}><Plus size={18} /></button>
    <button className="table-add-handle table-add-row" aria-label="Add row at table edge" title="Add row" disabled={rows >= 20} onClick={e => { e.stopPropagation(); onInsert("row"); }}><Plus size={18} /></button>
  </div>;
}

export function cropPanFromDelta(layer: DesignLayer, dx: number, dy: number): { cropX: number; cropY: number } {
  const zoom = Math.max(1, layer.cropZoom || 1), rangeX = Math.max(1, layer.width * (zoom - 1)), rangeY = Math.max(1, layer.height * (zoom - 1));
  return { cropX: Math.max(0, Math.min(1, (layer.cropX || 0) - dx / rangeX)), cropY: Math.max(0, Math.min(1, (layer.cropY || 0) - dy / rangeY)) };
}
