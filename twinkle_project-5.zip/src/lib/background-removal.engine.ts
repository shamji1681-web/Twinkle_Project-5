/**
 * Subject-segmentation engine for browser-side background removal.
 *
 * Ported from the original Web Worker version: Next.js/Turbopack has no support for
 * Vite's "?worker&inline" imports, so the ONNX runtime is loaded lazily on the main
 * thread instead. The model and WASM binaries are still fetched from the CDN and run
 * entirely client-side — photos never leave the browser.
 */
import type { BackgroundRemovalProgress } from "./background-removal.types";

interface Resource {
  size: number;
  mime: string;
  chunks: { name: string; offsets: [number, number] }[];
}

const ASSET_BASE = "https://staticimgly.com/@imgly/background-removal-data/1.7.0/dist/";
const RESOLUTION = 1024;

type Ort = typeof import("onnxruntime-web/wasm");
type OnnxSession = import("onnxruntime-common").InferenceSession;
type OnnxTensor = import("onnxruntime-common").Tensor;

let runtime: Promise<Ort> | null = null;
let session: Promise<OnnxSession> | null = null;

/**
 * The ONNX runtime is loaded lazily from the CDN (same 1.30.0 build the project depends on),
 * so its 14 MB WASM binary is never inlined into the single-file bundle. The WASM + glue
 * themselves are supplied at runtime through `ort.env.wasm.wasmPaths` below.
 */
const ORT_URL = "https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort.wasm.bundle.min.mjs";
function loadRuntime(): Promise<Ort> {
  return (runtime ??= import(/* @vite-ignore */ ORT_URL) as Promise<Ort>);
}

async function loadResource(resources: Record<string, Resource>, key: string, onProgress: (progress: BackgroundRemovalProgress) => void): Promise<Blob> {
  const resource = resources[key];
  if (!resource?.chunks.length) throw new Error(`Model resource missing: ${key}`);
  let downloaded = 0;
  const chunks = await Promise.all(resource.chunks.map(async chunk => {
    const response = await fetch(new URL(chunk.name, ASSET_BASE), { cache: "force-cache" });
    if (!response.ok) throw new Error(`Model download failed: ${response.status}`);
    const blob = await response.blob();
    if (blob.size !== chunk.offsets[1] - chunk.offsets[0]) throw new Error("Incomplete AI model download.");
    downloaded += blob.size;
    onProgress({ stage: "loading", message: key.startsWith("/models/") ? "Downloading AI model" : "Loading AI engine", percent: Math.round(downloaded / resource.size * 100) });
    return blob;
  }));
  const blob = new Blob(chunks, { type: resource.mime });
  if (blob.size !== resource.size) throw new Error("Incomplete AI resource.");
  return blob;
}

async function initialize(onProgress: (progress: BackgroundRemovalProgress) => void): Promise<OnnxSession> {
  const ort = await loadRuntime();
  const response = await fetch(new URL("resources.json", ASSET_BASE), { cache: "force-cache" });
  if (!response.ok) throw new Error("Could not download AI resource manifest.");
  const resources: Record<string, Resource> = await response.json();
  const model = await loadResource(resources, "/models/isnet_fp16", onProgress);
  const [wasm, mjs] = await Promise.all([
    loadResource(resources, "/onnxruntime-web/ort-wasm-simd-threaded.wasm", onProgress),
    loadResource(resources, "/onnxruntime-web/ort-wasm-simd-threaded.mjs", onProgress),
  ]);
  const wasmUrl = URL.createObjectURL(wasm);
  const runtimeUrl = URL.createObjectURL(mjs);
  // One WASM thread works in preview iframes without cross-origin isolation.
  ort.env.wasm.numThreads = 1;
  ort.env.wasm.proxy = false;
  ort.env.wasm.wasmPaths = { wasm: wasmUrl, mjs: runtimeUrl };
  onProgress({ stage: "loading", message: "Starting subject detection" });
  try {
    return await ort.InferenceSession.create(await model.arrayBuffer(), {
      executionProviders: ["wasm"],
      graphOptimizationLevel: "all",
    });
  } finally {
    URL.revokeObjectURL(wasmUrl);
    URL.revokeObjectURL(runtimeUrl);
  }
}

// The ISNet model expects 1024x1024 RGB in NCHW order, normalized by (pixel - 128) / 256.
function inputTensor(ort: Ort, pixels: Uint8Array, width: number, height: number): OnnxTensor {
  const plane = RESOLUTION * RESOLUTION;
  const input = new Float32Array(plane * 3);
  for (let y = 0; y < RESOLUTION; y++) {
    const sy = Math.min(height - 1, y * height / RESOLUTION);
    const y0 = Math.floor(sy), y1 = Math.min(height - 1, y0 + 1), dy = sy - y0;
    for (let x = 0; x < RESOLUTION; x++) {
      const sx = Math.min(width - 1, x * width / RESOLUTION);
      const x0 = Math.floor(sx), x1 = Math.min(width - 1, x0 + 1), dx = sx - x0;
      for (let channel = 0; channel < 3; channel++) {
        const top = pixels[(y0 * width + x0) * 4 + channel] * (1 - dx) + pixels[(y0 * width + x1) * 4 + channel] * dx;
        const bottom = pixels[(y1 * width + x0) * 4 + channel] * (1 - dx) + pixels[(y1 * width + x1) * 4 + channel] * dx;
        input[channel * plane + y * RESOLUTION + x] = (top * (1 - dy) + bottom * dy - 128) / 256;
      }
    }
  }
  return new ort.Tensor("float32", input, [1, 3, RESOLUTION, RESOLUTION]);
}

/** Runs subject segmentation: RGBA source in, per-pixel alpha mask out (same Blob format). */
export async function segmentSubject(image: Blob, onProgress: (progress: BackgroundRemovalProgress) => void): Promise<Blob> {
  const width = Number(/width=(\d+)/.exec(image.type)?.[1]);
  const height = Number(/height=(\d+)/.exec(image.type)?.[1]);
  if (!width || !height || width > 2048 || height > 2048) throw new Error("Invalid image dimensions.");
  const pixels = new Uint8Array(await image.arrayBuffer());
  if (pixels.length !== width * height * 4) throw new Error("Invalid image pixels.");
  const ort = await loadRuntime();
  const engine = await (session ??= initialize(onProgress));
  onProgress({ stage: "segmenting", message: "Detecting the subject" });
  const input = inputTensor(ort, pixels, width, height);

  let outputs: Record<string, OnnxTensor> | undefined;
  try {
    const result = await engine.run({ [engine.inputNames[0]]: input });
    outputs = result;
    const output = result[engine.outputNames[0]];
    const mask = output.data;
    if (!(mask instanceof Float32Array) || mask.length !== RESOLUTION * RESOLUTION || !mask.every(Number.isFinite)) throw new Error("Invalid AI mask.");
    onProgress({ stage: "refining", message: "Refining subject edges" });
    // Bilinear upsampling retains soft hair/fur edges rather than making a hard cut.
    for (let y = 0; y < height; y++) {
      const sy = Math.min(RESOLUTION - 1, y * RESOLUTION / height);
      const y0 = Math.floor(sy), y1 = Math.min(RESOLUTION - 1, y0 + 1), dy = sy - y0;
      for (let x = 0; x < width; x++) {
        const sx = Math.min(RESOLUTION - 1, x * RESOLUTION / width);
        const x0 = Math.floor(sx), x1 = Math.min(RESOLUTION - 1, x0 + 1), dx = sx - x0;
        const top = mask[y0 * RESOLUTION + x0] * (1 - dx) + mask[y0 * RESOLUTION + x1] * dx;
        const bottom = mask[y1 * RESOLUTION + x0] * (1 - dx) + mask[y1 * RESOLUTION + x1] * dx;
        const alpha = Math.max(0, Math.min(1, top * (1 - dy) + bottom * dy));
        pixels[(y * width + x) * 4 + 3] = Math.round(alpha * 255);
      }
    }
    return new Blob([pixels], { type: image.type });
  } finally {
    input.dispose();
    if (outputs) for (const output of Object.values(outputs)) output.dispose();
  }
}
