/**
 * Custom font uploads. Fonts are stored (as data URLs) in localStorage so they persist,
 * loaded into the document via FontFace, and their family names become valid in designs.
 */
import { FONTS } from "@/lib/designs";

export interface CustomFont { name: string; dataUrl: string }

const KEY = "creato-fonts-v1";
const MAX_FONT_BYTES = 2_600_000; // ~2 MB font file
const listeners = new Set<() => void>();
let cache: CustomFont[] | null = null;
const loaded = new Set<string>();

function read(): CustomFont[] {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    cache = Array.isArray(parsed) ? parsed.filter(f => f && typeof f.name === "string" && typeof f.dataUrl === "string") : [];
  } catch { cache = []; }
  return cache;
}

function persist(fonts: CustomFont[]) {
  cache = fonts;
  localStorage.setItem(KEY, JSON.stringify(fonts));
  listeners.forEach(fn => fn());
}

/** All font family names — built-in first, then the user's uploads. */
export function allFontNames(): string[] {
  return [...FONTS, ...read().map(f => f.name)];
}

export function customFonts(): CustomFont[] {
  return read();
}

export function isKnownFont(name: string): boolean {
  return allFontNames().includes(name);
}

/** Registers a stored font with the browser so text renders in it. Safe to call repeatedly. */
export function ensureFontLoaded(font: CustomFont) {
  if (loaded.has(font.name) || typeof document === "undefined" || !("fonts" in document)) return;
  try {
    const face = new FontFace(font.name, `url(${font.dataUrl})`);
    face.load().then(f => { document.fonts.add(f); }).catch(() => {});
    loaded.add(font.name);
  } catch { /* Older browsers without FontFace simply skip custom fonts. */ }
}

/** Loads every stored custom font. Call once when the editor mounts. */
export function loadAllCustomFonts() {
  read().forEach(ensureFontLoaded);
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("That font file couldn't be read."));
    reader.readAsDataURL(file);
  });
}

const cleanName = (raw: string) =>
  raw.replace(/\.(ttf|otf|woff2?|TTF|OTF|WOFF2?)$/i, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 40) || "Custom font";

/** Reads, validates and stores an uploaded font file. Returns the registered family name. */
export async function uploadFont(file: File): Promise<string> {
  if (!/\.(ttf|otf|woff2?)$/i.test(file.name) && !/font|octet-stream/i.test(file.type)) {
    throw new Error("Choose a TTF, OTF, WOFF or WOFF2 font file.");
  }
  if (file.size > MAX_FONT_BYTES) throw new Error("Please choose a font file under 2 MB.");
  const dataUrl = await readFileAsDataUrl(file);

  let name = cleanName(file.name);
  const existing = read();
  if (FONTS.includes(name) || existing.some(f => f.name === name)) {
    let n = 2;
    while (FONTS.includes(`${name} ${n}`) || existing.some(f => f.name === `${name} ${n}`)) n++;
    name = `${name} ${n}`;
  }

  // Validate that the browser can actually parse the font before saving it.
  try {
    const face = new FontFace(name, `url(${dataUrl})`);
    await face.load();
    document.fonts.add(face);
    loaded.add(name);
  } catch {
    throw new Error("This font file couldn't be loaded. Try a different TTF, OTF or WOFF file.");
  }

  const font: CustomFont = { name, dataUrl };
  try { persist([...existing, font]); }
  catch { throw new Error("Your browser storage is full. Remove a font or some designs, then try again."); }
  return name;
}

export function removeFont(name: string) {
  persist(read().filter(f => f.name !== name));
}

/** Subscribe to font-list changes (for React's useSyncExternalStore). */
export function subscribeFonts(listener: () => void) {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

export function fontsSnapshot(): CustomFont[] {
  return read();
}
