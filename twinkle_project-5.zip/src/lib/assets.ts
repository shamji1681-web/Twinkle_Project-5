export interface StockPhoto { src: string; name: string; tags: string; credit: string }
export interface GradientAsset { name: string; value: string }
export interface PatternAsset { key: string; name: string }

export const stockPhotos: StockPhoto[] = [
  { src: "/images/photos/flowers.jpg", name: "Golden flowers", tags: "nature flowers yellow soft", credit: "Egor Komarov" },
  { src: "/images/photos/meadow.jpg", name: "Wildflower meadow", tags: "nature spring colorful field", credit: "Ramaz Bluashvili" },
  { src: "/images/photos/cosmos.jpg", name: "White cosmos", tags: "nature garden white calm", credit: "Chris Harvey" },
  { src: "/images/photos/coffee.jpg", name: "Coffee and notes", tags: "coffee desk work warm", credit: "Cup of Couple" },
  { src: "/images/photos/desk.jpg", name: "Minimal desk", tags: "desk planner watch wood", credit: "Content Pixie" },
  { src: "/images/photos/notebook.jpg", name: "Notebook flat lay", tags: "notebook pen white study", credit: "Cup of Couple" },
  { src: "/images/photos/lake.jpg", name: "Misty mountains", tags: "mountain lake fog moody", credit: "Erik Mclean" },
  { src: "/images/photos/alpine.jpg", name: "Alpine sunrise", tags: "lake sunrise alps reflection", credit: "Gerhard adF Hofmarcher" },
  { src: "/images/photos/valley.jpg", name: "Foggy valley", tags: "valley fog calm landscape", credit: "Erik Mclean" },
  { src: "/images/photos/gradient-paper.jpg", name: "Rolled gradient", tags: "abstract gradient paper colorful", credit: "Saifee Art" },
  { src: "/images/photos/pastel-paper.jpg", name: "Pastel layers", tags: "abstract pastel paper layers", credit: "Katie Rainbow" },
  { src: "/images/photos/blush-paper.jpg", name: "Blush texture", tags: "abstract blush pink texture", credit: "kaboompics" },
  { src: "/images/interior.jpg", name: "Minimal interior", tags: "interior beige chair plant", credit: "dada_design" },
  { src: "/images/coast.jpg", name: "Positano coast", tags: "travel italy sea summer", credit: "Rosa Stone" },
  { src: "/images/skincare.jpg", name: "Amber bottles", tags: "product skincare beige", credit: "Liana Horodetska" },
];

export const gradients: GradientAsset[] = [
  { name: "Lavender dusk", value: "linear-gradient(135deg, #a78bfa 0%, #f0abfc 100%)" },
  { name: "Peach glow", value: "linear-gradient(135deg, #fdba74 0%, #fca5a5 100%)" },
  { name: "Fresh mint", value: "linear-gradient(135deg, #a7f3d0 0%, #bae6fd 100%)" },
  { name: "Deep forest", value: "linear-gradient(160deg, #064e3b 0%, #14532d 100%)" },
  { name: "Night sky", value: "linear-gradient(160deg, #312e81 0%, #6d28d9 100%)" },
  { name: "Warm sand", value: "linear-gradient(135deg, #fde68a 0%, #fdba74 100%)" },
  { name: "Blush pink", value: "linear-gradient(135deg, #fecdd3 0%, #fbcfe8 100%)" },
  { name: "Slate calm", value: "linear-gradient(160deg, #e2e8f0 0%, #cbd5e1 100%)" },
  { name: "Sunset sea", value: "linear-gradient(135deg, #fb7185 0%, #f59e0b 100%)" },
  { name: "Cream paper", value: "linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)" },
  { name: "Ocean deep", value: "linear-gradient(160deg, #0ea5e9 0%, #1e3a8a 100%)" },
  { name: "Soft lilac", value: "linear-gradient(135deg, #ede9fe 0%, #fae8ff 100%)" },
];

export const patterns: PatternAsset[] = [
  { key: "dots", name: "Dots" },
  { key: "grid", name: "Grid" },
  { key: "stripes", name: "Stripes" },
  { key: "checks", name: "Checks" },
  { key: "waves", name: "Waves" },
  { key: "confetti", name: "Confetti" },
];

export const canvasPresets = [
  { name: "Business card", category: "Business card", width: 1050, height: 600 },
  { name: "ID card", category: "ID card", width: 660, height: 1040 },
  { name: "Visitor pass", category: "ID card", width: 1013, height: 638 },
  { name: "Letterhead", category: "Letterhead", width: 850, height: 1100 },
  { name: "Envelope DL", category: "Envelope", width: 1000, height: 500 },
  { name: "Flyer", category: "Flayer", width: 1000, height: 1400 },
  { name: "Brochure", category: "Boucher", width: 1400, height: 1000 },
  { name: "Mug wrap", category: "Mug", width: 2400, height: 1100 },
  { name: "T-shirt print", category: "T-Shirt", width: 1800, height: 2400 },
  { name: "Diary cover", category: "Dairie", width: 1000, height: 1400 },
  { name: "Bill book", category: "Bill & Vouch Book", width: 1200, height: 800 },
  { name: "Flex banner", category: "Banner", width: 2000, height: 800 },
  { name: "Gift frame", category: "Customise Gift", width: 1200, height: 1200 },
  { name: "Instagram post", category: "Social Media", width: 1080, height: 1080 },
  { name: "Instagram story", category: "Social Media", width: 1080, height: 1920 },
  { name: "Website hero", category: "Websites", width: 1600, height: 1000 },
  { name: "Video cover", category: "Video", width: 1600, height: 900 },
  { name: "Poster", category: "More", width: 1200, height: 1600 },
];
