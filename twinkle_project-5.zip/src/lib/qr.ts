export type QRDotStyle = "square" | "rounded" | "dots" | "diamond";
export type QRCornerStyle = "square" | "rounded" | "circle";
export type QRErrorCorrection = "L" | "M" | "Q" | "H";
export type QRContentType = "url" | "social" | "wifi" | "vcard" | "location" | "text";
export interface QRContent { type: QRContentType; value?: string; platform?: string; handle?: string; ssid?: string; password?: string; encryption?: "WPA" | "WEP" | "nopass"; hidden?: boolean; firstName?: string; lastName?: string; phone?: string; email?: string; organization?: string; address?: string; latitude?: string; longitude?: string; }

export interface QRSettings {
  text: string;
  dotStyle: QRDotStyle;
  cornerStyle: QRCornerStyle;
  margin: number;
  errorCorrection: QRErrorCorrection;
  fg: string;
  fg2: string;
  gradient: boolean;
  bg: string;
  transparent: boolean;
  logo: boolean;
  customLogo?: string | null;
  logoScale?: number;
  content?: QRContent;
}

export const defaultQRSettings: QRSettings = {
  text: "",
  dotStyle: "rounded",
  cornerStyle: "rounded",
  margin: 2,
  errorCorrection: "M",
  fg: "#24232b",
  fg2: "#7c4de0",
  gradient: false,
  bg: "#ffffff",
  transparent: false,
  logo: false,
  customLogo: null,
  logoScale: 0.23,
  content: { type: "url", value: "" },
};

export const dotStyles: { key: QRDotStyle; name: string }[] = [
  { key: "square", name: "Square" },
  { key: "rounded", name: "Rounded" },
  { key: "dots", name: "Dots" },
  { key: "diamond", name: "Diamond" },
];

export const cornerStyles: { key: QRCornerStyle; name: string }[] = [
  { key: "square", name: "Square" },
  { key: "rounded", name: "Rounded" },
  { key: "circle", name: "Circle" },
];

export const errorLevels: { key: QRErrorCorrection; name: string; note: string }[] = [
  { key: "L", name: "Low", note: "Smaller, cleaner code" },
  { key: "M", name: "Medium", note: "Balanced for everyday use" },
  { key: "Q", name: "Quartile", note: "Good with a logo" },
  { key: "H", name: "High", note: "Best with a logo" },
];

export const qrPresets: { name: string; settings: Partial<QRSettings> }[] = [
  { name: "Classic", settings: { dotStyle: "square", cornerStyle: "square", fg: "#111111", bg: "#ffffff", gradient: false, transparent: false, margin: 2 } },
  { name: "Soft", settings: { dotStyle: "rounded", cornerStyle: "rounded", fg: "#3b2f45", bg: "#fdf8ff", gradient: false, transparent: false, margin: 2 } },
  { name: "Dotted", settings: { dotStyle: "dots", cornerStyle: "circle", fg: "#24232b", bg: "#ffffff", gradient: false, transparent: false, margin: 3 } },
  { name: "Gradient", settings: { dotStyle: "rounded", cornerStyle: "circle", fg: "#7c4de0", fg2: "#f0559b", gradient: true, bg: "#ffffff", transparent: false, margin: 2 } },
  { name: "On brand", settings: { dotStyle: "diamond", cornerStyle: "rounded", fg: "#064e48", fg2: "#8caba4", gradient: true, bg: "#eef7f2", transparent: false, margin: 3 } },
  { name: "Invisible", settings: { dotStyle: "dots", cornerStyle: "circle", fg: "#24232b", bg: "#ffffff", gradient: false, transparent: true, margin: 1 } },
];

const HEX = /^#[0-9a-f]{6}$/i;
const DOT_KEYS: QRDotStyle[] = ["square", "rounded", "dots", "diamond"];
const CORNER_KEYS: QRCornerStyle[] = ["square", "rounded", "circle"];
const EC_KEYS: QRErrorCorrection[] = ["L", "M", "Q", "H"];

export function socialUrl(platform?: string, handle?: string): string {
  const h = (handle || "").replace(/^@/, "").trim();
  if (!h) return "";
  switch (platform) {
    case "instagram": return `https://instagram.com/${h}`;
    case "whatsapp": return `https://wa.me/${h.replace(/[^0-9]/g, "")}`;
    case "youtube": return h.startsWith("http") ? h : `https://youtube.com/@${h}`;
    case "twitter": return `https://x.com/${h}`;
    case "facebook": return h.startsWith("http") ? h : `https://facebook.com/${h}`;
    case "tiktok": return `https://tiktok.com/@${h}`;
    case "linkedin": return h.startsWith("http") ? h : `https://linkedin.com/in/${h}`;
    case "telegram": return `https://t.me/${h}`;
    case "snapchat": return `https://snapchat.com/add/${h}`;
    default: return `https://${h}`;
  }
}

export function qrPayload(content: QRContent): string {
  const clean = (v?: string) => (v || "").replace(/[\\;,:]/g, "\\$&").trim();
  if (content.type === "social") return socialUrl(content.platform, content.handle);
  if (content.type === "wifi") {
    // Standard WIFI: payload — scanners offer "Connect" straight away.
    const password = (content.password || "").trim();
    const encryption = password ? (content.encryption || "WPA") : "nopass";
    const parts = [`T:${encryption}`, `S:${clean(content.ssid)}`, `P:${clean(password)}`];
    if (content.hidden) parts.push("H:true");
    return `WIFI:${parts.join(";")};;`;
  }
  if (content.type === "vcard") return ["BEGIN:VCARD","VERSION:3.0",`N:${clean(content.lastName)};${clean(content.firstName)};;;`,`FN:${clean(`${content.firstName || ""} ${content.lastName || ""}`)}`,content.organization ? `ORG:${clean(content.organization)}` : "",content.phone ? `TEL:${clean(content.phone)}` : "",content.email ? `EMAIL:${clean(content.email)}` : "",content.address ? `ADR:;;${clean(content.address)};;;;` : "","END:VCARD"].filter(Boolean).join("\n");
  if (content.type === "location") { const lat = (content.latitude || "").trim(), lng = (content.longitude || "").trim(); return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`; }
  return (content.value || "").trim();
}
export function normalizeQRContent(raw: unknown, fallback: QRContent = { type: "url", value: "" }): QRContent {
  const source = raw && typeof raw === "object" ? raw as Partial<QRContent> : {};
  const type: QRContentType = ["url","social","wifi","vcard","location","text"].includes(source.type || "") ? source.type as QRContentType : fallback.type;
  const text = (value: unknown, max = 300) => typeof value === "string" ? value.trim().slice(0,max) : "";
  return { type, value:text(source.value,1200), platform:text(source.platform,50), handle:text(source.handle,200), ssid:text(source.ssid), password:text(source.password), encryption:["WPA","WEP","nopass"].includes(source.encryption || "") ? source.encryption as QRContent["encryption"] : "WPA", hidden:!!source.hidden, firstName:text(source.firstName), lastName:text(source.lastName), phone:text(source.phone), email:text(source.email), organization:text(source.organization), address:text(source.address), latitude:text(source.latitude,32), longitude:text(source.longitude,32) };
}
export function validQRContent(content: QRContent) {
  if (content.type === "social") return !!content.handle?.trim();
  if (content.type === "wifi") return !!content.ssid;
  if (content.type === "vcard") return !!(content.firstName || content.lastName || content.phone || content.email);
  if (content.type === "location") return /^-?\d{1,2}(\.\d+)?$/.test(content.latitude || "") && /^-?\d{1,3}(\.\d+)?$/.test(content.longitude || "") && Math.abs(Number(content.latitude)) <= 90 && Math.abs(Number(content.longitude)) <= 180;
  return !!content.value?.trim();
}

/** Validates and clamps QR settings coming from the client or a stored design. */
export function normalizeQRSettings(raw: unknown, fallback: Partial<QRSettings> = {}): QRSettings {
  const source = (raw && typeof raw === "object" ? raw : {}) as Partial<QRSettings>;
  const pick = <T extends string>(value: unknown, allowed: T[], iffy: T): T => allowed.includes(value as T) ? value as T : iffy;
  const content = normalizeQRContent(source.content, fallback.content);
  const text = validQRContent(content) ? qrPayload(content) : (typeof source.text === "string" ? source.text.trim().slice(0,1200) : (fallback.text || ""));
  return {
    text,
    dotStyle: pick(source.dotStyle, DOT_KEYS, fallback.dotStyle || defaultQRSettings.dotStyle),
    cornerStyle: pick(source.cornerStyle, CORNER_KEYS, fallback.cornerStyle || defaultQRSettings.cornerStyle),
    margin: Number.isFinite(source.margin) ? Math.max(0, Math.min(8, Math.round(source.margin as number))) : fallback.margin ?? defaultQRSettings.margin,
    errorCorrection: pick(source.errorCorrection, EC_KEYS, fallback.errorCorrection || defaultQRSettings.errorCorrection),
    fg: HEX.test(source.fg || "") ? (source.fg as string) : fallback.fg || defaultQRSettings.fg,
    fg2: HEX.test(source.fg2 || "") ? (source.fg2 as string) : fallback.fg2 || defaultQRSettings.fg2,
    gradient: typeof source.gradient === "boolean" ? source.gradient : fallback.gradient ?? defaultQRSettings.gradient,
    bg: HEX.test(source.bg || "") ? (source.bg as string) : fallback.bg || defaultQRSettings.bg,
    transparent: typeof source.transparent === "boolean" ? source.transparent : fallback.transparent ?? defaultQRSettings.transparent,
    logo: typeof source.logo === "boolean" ? source.logo : fallback.logo ?? defaultQRSettings.logo,
    customLogo: typeof source.customLogo === "string" ? source.customLogo : fallback.customLogo ?? null,
    logoScale: Number.isFinite(source.logoScale) ? Math.max(.12, Math.min(.34, source.logoScale as number)) : fallback.logoScale ?? 0.23,
    content,
  };
}

export function isQRSettings(value: unknown): boolean {
  if (!value || typeof value !== "object") return false;
  const settings = value as Partial<QRSettings>;
  if (typeof settings.text !== "string" || settings.text.length < 2 || settings.text.length > 1200) return false;
  if (!DOT_KEYS.includes(settings.dotStyle as QRDotStyle)) return false;
  if (!CORNER_KEYS.includes(settings.cornerStyle as QRCornerStyle)) return false;
  if (!EC_KEYS.includes(settings.errorCorrection as QRErrorCorrection)) return false;
  if (!Number.isInteger(settings.margin) || (settings.margin as number) < 0 || (settings.margin as number) > 8) return false;
  if (!HEX.test(settings.fg || "") || !HEX.test(settings.fg2 || "") || !HEX.test(settings.bg || "")) return false;
  return typeof settings.gradient === "boolean" && typeof settings.transparent === "boolean" && typeof settings.logo === "boolean" && (settings.content === undefined || validQRContent(normalizeQRContent(settings.content)));
}


import { BRAND_LOGOS, BRAND_PREFIX } from "@/lib/brand-logos";

export { BRAND_PREFIX };
/** Keys of the built-in centre logos, e.g. "brand:whatsapp". */
export const isBrandLogo = (value?: string | null): boolean => !!value && value.startsWith(BRAND_PREFIX);
export const brandLogoKey = (value?: string | null): string => (value && value.startsWith(BRAND_PREFIX) ? value.slice(BRAND_PREFIX.length) : "");
export const brandLogoNames = BRAND_LOGOS.map(l => l.key);
