import { useEffect, useRef, useState } from "react";
import { resolveAsset } from "@/lib/asset-map";
import { AlignCenter, AlignJustify, AlignLeft, AlignRight, ArrowRight, ArrowUpDown, Ban, Bold, CaseSensitive, Check, ChevronDown, Diamond, Italic, List, ListOrdered, Minus, Star, Strikethrough, Type, Underline, Wand2 } from "lucide-react";
import { FONTS, gradientCss } from "@/lib/designs";
import { useCustomFonts } from "@/lib/use-fonts";
import { pxToPt, ptToPx } from "@/lib/table";
import { justifyAlignPatch, BULLET_VARIANTS, NUMBER_FORMATS } from "@/lib/text-fit";
import { toggleScriptRange, type ScriptKind } from "@/lib/script-text";
import type { EditorContext } from "@/components/editor-panels";

export type TextMenu = "fill" | "case" | "spacing" | "list" | "fraction";

/** Bullet styles as toolbar icons instead of text names. */
export const LIST_ICONS = {
  none: Ban,
  bullet: List,
  number: ListOrdered,
  dash: Minus,
  arrow: ArrowRight,
  check: Check,
  star: Star,
  diamond: Diamond,
} as const;

interface Props { ctx: EditorContext; onMenu: (name: TextMenu) => void; activeMenu: string | null }

function NumericField({ label, value, min, max, onCommit }: { label: string; value: number; min: number; max: number; onCommit: (v: number) => void }) {
  const [draft, setDraft] = useState(String(Number(value.toFixed(2))));
  const focused = useRef(false), cancelled = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(String(Number(value.toFixed(2)))); }, [value]);
  return <input className="text-property-number" type="number" step="0.1" min={min} max={max} aria-label={label} value={draft} onFocus={() => { focused.current = true; cancelled.current = false; }} onChange={e => setDraft(e.target.value)} onBlur={() => {
    focused.current = false;
    if (cancelled.current || !draft.trim() || !Number.isFinite(Number(draft))) { setDraft(String(Number(value.toFixed(2)))); return; }
    const next = Math.max(min, Math.min(max, Number(draft))); onCommit(next); setDraft(String(Number(next.toFixed(2))));
  }} onKeyDown={e => { e.stopPropagation(); if (e.key === "Enter") e.currentTarget.blur(); if (e.key === "Escape") { cancelled.current = true; e.currentTarget.blur(); } }} />;
}

export default function TextProperties({ ctx, onMenu, activeMenu }: Props) {
  const fonts = useCustomFonts();
  const text = ctx.selected!;
  const fill = text.fillImage ? `url(${resolveAsset(text.fillImage)}) center/cover` : text.fillGradient ? gradientCss(text.fillGradient) : text.fill;

  function toggleScript(kind: ScriptKind) {
    // A highlight (or the focused cursor) formats just those words — real H₂O / x² on
    // canvas, for every character and font. No focus: the whole box shifts.
    const overlay = ctx.editingId === text.id ? document.querySelector<HTMLTextAreaElement>(".text-edit-overlay") : null;
    const start = overlay?.selectionStart ?? -1, end = overlay?.selectionEnd ?? -1;
    if (overlay && start >= 0 && end > start) {
      const full = text.text || "";
      const ranges = toggleScriptRange(full, text.scriptRanges, start, end, kind);
      const cleared = (text.scriptRanges?.length || 0) > 0 && ranges.length < (text.scriptRanges?.length || 0) && ranges.every(r => !(r.start < end && r.end > start));
      ctx.patch(text.id, { scriptRanges: ranges.length ? ranges : undefined, script: undefined });
      ctx.notify(cleared ? "Back to regular text." : kind === "super" ? "Superscript applied to selection (x²)." : "Subscript applied to selection (x₂).");
      requestAnimationFrame(() => {
        const node = document.querySelector<HTMLTextAreaElement>(".text-edit-overlay");
        if (node) { node.focus({ preventScroll: true }); node.setSelectionRange(start, end); }
      });
      return;
    }
    ctx.patch(text.id, { script: text.script === kind ? undefined : kind, scriptRanges: undefined });
  }

  const activeListSymbol = text.listStyle === "number"
    ? NUMBER_FORMATS.find(f => f.key === (text.listNumberFormat || "number"))?.sample || "1."
    : text.listStyle === "bullet"
      ? BULLET_VARIANTS.find(b => b.key === (text.listBulletVariant || "bullet"))?.mark || "•"
      : null;

  return <>
    <span className="context-chip text-chip"><Type size={13} />Text</span>
    <select className="text-font-select" aria-label="Font family" value={text.fontFamily || "Arial"} onChange={e => ctx.patch(text.id, { fontFamily: e.target.value })}>
      <optgroup label="Fonts">{FONTS.map(font => <option key={font} value={font} style={{ fontFamily: font }}>{font}</option>)}</optgroup>
      {fonts.length > 0 && <optgroup label="Your uploads">{fonts.map(font => <option key={font.name} value={font.name} style={{ fontFamily: font.name }}>{font.name}</option>)}</optgroup>}
    </select>
    <label className="text-point-size"><NumericField label="Font size" value={pxToPt(text.fontSize || 40)} min={6} max={750} onCommit={v => ctx.patch(text.id, { fontSize: ptToPx(v) })} /><small>pt</small></label>
    <button data-popover-trigger="fill" className="text-fill-button" title="Text fill · solid, gradient or image" aria-label="Element fill" aria-expanded={activeMenu === "fill"} onClick={() => onMenu("fill")} style={{ background: fill }}><span /></button>
    <span className="context-divider" />
    <button className={`context-icon ${(text.fontWeight || 400) >= 600 ? "active" : ""}`} aria-label="Bold text" aria-pressed={(text.fontWeight || 400) >= 600} title="Bold" onClick={() => ctx.patch(text.id, { fontWeight: (text.fontWeight || 400) >= 600 ? 400 : 700 })}><Bold size={15} /></button>
    <button className={`context-button text-extra-bold ${(text.fontWeight || 400) >= 900 ? "active" : ""}`} aria-label="Extra bold text" aria-pressed={(text.fontWeight || 400) >= 900} title="Extra Bold · 900" onClick={() => ctx.patch(text.id, { fontWeight: (text.fontWeight || 400) >= 900 ? 400 : 900 })}><Bold size={14} /><span>900</span></button>
    <button className={`context-icon ${text.italic ? "active" : ""}`} aria-label="Italic text" aria-pressed={!!text.italic} title="Italic" onClick={() => ctx.patch(text.id, { italic: !text.italic })}><Italic size={15} /></button>
    <button className={`context-icon ${text.underline ? "active" : ""}`} aria-label="Underline text" aria-pressed={!!text.underline} title="Underline" onClick={() => ctx.patch(text.id, { underline: !text.underline })}><Underline size={15} /></button>
    <button className={`context-icon ${text.strikethrough ? "active" : ""}`} aria-label="Strikethrough text" aria-pressed={!!text.strikethrough} title="Strikethrough" onClick={() => ctx.patch(text.id, { strikethrough: !text.strikethrough })}><Strikethrough size={15} /></button>
    <span className="context-divider" />
    <div className="text-align-switch" role="group" aria-label="Text alignment">
      {([
        { key: "left", Icon: AlignLeft, label: "Left" },
        { key: "center", Icon: AlignCenter, label: "Center" },
        { key: "right", Icon: AlignRight, label: "Right" },
        { key: "justify", Icon: AlignJustify, label: "Full justify · CorelDRAW: every line stretches to the frame; each paragraph's last line stays natural" },
        { key: "justify-all", Icon: AlignJustify, label: "Force justify · CorelDRAW: every line stretches to the frame, last lines and single words included" },
      ] as const).map(({ key, Icon, label }) => (
        <button key={key} className={(text.align || "left") === key ? "active" : ""} aria-label={`Align ${label}`} aria-pressed={(text.align || "left") === key} title={label} onClick={() => { const { patch, converted } = justifyAlignPatch(text, key, ctx.doc.width); ctx.patch(text.id, patch); if (converted) ctx.notify("Justification uses a fixed frame — auto-fit is off. Drag the side handles to rewrap."); }}>
          <Icon size={key === "justify-all" ? 13 : 15} strokeWidth={key === "justify-all" ? 2.4 : 2} style={key === "justify-all" ? { transform: "scaleX(1.35)" } : undefined} />
        </button>
      ))}
    </div>
    <button data-popover-trigger="spacing" className="context-button text-spacing-button" aria-label="Line spacing" aria-expanded={activeMenu === "spacing"} title="Line spacing" onClick={() => onMenu("spacing")}><ArrowUpDown size={14} />{(text.lineHeight ?? 1.13).toFixed(2)}<ChevronDown size={11} /></button>
    <button data-popover-trigger="case" className="context-button" aria-label="Change text case" title="Text case" onClick={() => onMenu("case")}><CaseSensitive size={16} /><ChevronDown size={11} /></button>
    <button data-popover-trigger="list" className={`context-button text-list-button ${text.listStyle && text.listStyle !== "none" ? "active" : ""}`} aria-label="Bullet and numbering style" aria-expanded={activeMenu === "list"} title="Bullets &amp; Numbering · Word style" onClick={() => onMenu("list")}>
      {activeListSymbol ? <span style={{ fontWeight: 700, fontSize: 13, minWidth: 14 }}>{activeListSymbol}</span> : <List size={15} />}
      <ChevronDown size={11} />
    </button>
    <button className={`context-icon ${text.dropCap ? "active" : ""}`} aria-label="Drop cap" aria-pressed={!!text.dropCap} title="Drop cap · Word: enlarge opening letter across lines" onClick={() => {
      if (text.dropCap) ctx.patch(text.id, { dropCap: undefined, dropCapMargin: undefined, dropCapLines: undefined, dropCapGap: undefined, dropCapFont: undefined, dropCapFill: undefined });
      else ctx.patch(text.id, { dropCap: true });
    }}>
      <span className="dropcap-glyph" aria-hidden="true" style={text.dropCapFill ? { color: text.dropCapFill } : undefined}>A</span>
    </button>
    <button className={`context-icon ${text.script === "sub" || text.scriptRanges?.some(r => r.kind === "sub") ? "active" : ""}`} aria-label="Subscript (Ctrl+=)" aria-pressed={text.script === "sub"} title="Subscript (Ctrl+=) · Word: highlight selection or shift whole box" onPointerDown={e => e.preventDefault()} onClick={() => toggleScript("sub")}><span className="script-glyph" aria-hidden="true">X<sub>2</sub></span></button>
    <button className={`context-icon ${text.script === "super" || text.scriptRanges?.some(r => r.kind === "super") ? "active" : ""}`} aria-label="Superscript (Ctrl+Shift+=)" aria-pressed={text.script === "super"} title="Superscript (Ctrl+Shift+=) · Word: highlight selection or shift whole box" onPointerDown={e => e.preventDefault()} onClick={() => toggleScript("super")}><span className="script-glyph" aria-hidden="true">X<sup>2</sup></span></button>
    <button data-popover-trigger="fraction" className={`context-button text-list-button ${activeMenu === "fraction" ? "active" : ""}`} aria-label="Fractions" aria-expanded={activeMenu === "fraction"} title="Fractions (½) · Normal, Superscript (^½), Subscript (v½)" onClick={() => onMenu("fraction")}>
      <span className="fraction-glyph" aria-hidden="true">½</span>
      <ChevronDown size={11} />
    </button>
    <button className="context-button text-effects-link" aria-label="Open effects" onClick={() => ctx.openPanel("effects")}><Wand2 size={14} />Effects</button>
  </>;
}
