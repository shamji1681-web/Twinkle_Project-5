import type { DesignLayer } from "@/lib/designs";
import { cellTextOverrides, isCellTextStyle, type CellTextStyle } from "@/lib/cell-typography";
import { gradientCss, hexWithAlpha, isGradientFill, type GradientFill } from "@/lib/gradient";

export interface CellRef { r: number; c: number }
export interface Merge { r: number; c: number; rowspan: number; colspan: number }
export type TableAxis = "row" | "column";
export type BorderLineStyle = "none" | "solid" | "dashed" | "dotted";
export interface TableBorder { color: string; width: number; style: BorderLineStyle }
export type BorderTarget = "all" | "outer" | "inner" | "top" | "horizontal" | "bottom" | "left" | "vertical" | "right";
export type LengthUnit = "px" | "mm" | "in";
export const MAX_TABLE_ROWS = 20;
export const MAX_TABLE_COLS = 12;
export const MIN_TRACK = 0.02;
const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));
const colour = (v: unknown) => typeof v === "string" && (/^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(v) || v === "transparent");

export const toDisplayUnit = (px: number, unit: LengthUnit) => unit === "mm" ? px * 25.4 / 96 : unit === "in" ? px / 96 : px;
export const fromDisplayUnit = (value: number, unit: LengthUnit) => unit === "mm" ? value * 96 / 25.4 : unit === "in" ? value * 96 : value;
export const pxToPt = (px: number) => px * .75;
export const ptToPx = (pt: number) => pt / .75;
export function tableSize(layer: DesignLayer) { return { rows: Math.max(1, layer.rows ?? 3), cols: Math.max(1, layer.cols ?? 3) }; }
export function cellIndex(cols: number, r: number, c: number) { return r * cols + c; }
export const cellKey = (r: number, c: number) => `${r}:${c}`;

/** Normalise tracks without ever creating a track too small to be saved or grabbed. */
export function normaliseTracks(values: number[]): number[] {
  if (!values.length) return [1];
  const weights = values.map(v => Number.isFinite(v) && v > 0 ? v : 1);
  const result = new Array<number>(weights.length).fill(0);
  const remaining = new Set(weights.map((_, i) => i));
  let budget = 1;
  while (remaining.size) {
    const total = [...remaining].reduce((sum, i) => sum + weights[i], 0);
    const tooSmall = [...remaining].filter(i => weights[i] / total * budget < MIN_TRACK);
    if (!tooSmall.length) { remaining.forEach(i => { result[i] = weights[i] / total * budget; }); break; }
    tooSmall.forEach(i => { result[i] = MIN_TRACK; budget -= MIN_TRACK; remaining.delete(i); });
  }
  return result;
}

export function tableFractions(layer: DesignLayer, axis: TableAxis) {
  const { rows, cols } = tableSize(layer);
  const count = axis === "row" ? rows : cols;
  const value = axis === "row" ? layer.rowHeights : layer.colWidths;
  return value?.length === count ? normaliseTracks(value) : Array.from({ length: count }, () => 1 / count);
}

export function tableTracks(layer: DesignLayer, width = layer.width, height = layer.height) {
  const { rows, cols } = tableSize(layer);
  const xs = [0], ys = [0];
  tableFractions(layer, "column").forEach(fr => xs.push(xs[xs.length - 1] + fr * width));
  tableFractions(layer, "row").forEach(fr => ys.push(ys[ys.length - 1] + fr * height));
  xs[cols] = width; ys[rows] = height;
  return { rows, cols, xs, ys };
}

export function mergeAt(layer: DesignLayer, r: number, c: number): Merge | undefined {
  return (layer.merges || []).find(m => r >= m.r && r < m.r + m.rowspan && c >= m.c && c < m.c + m.colspan);
}
export function isCovered(layer: DesignLayer, r: number, c: number) { const m = mergeAt(layer, r, c); return !!m && (m.r !== r || m.c !== c); }
export function visibleCells(layer: DesignLayer): CellRef[] {
  const { rows, cols } = tableSize(layer), out: CellRef[] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) if (!isCovered(layer, r, c)) out.push({ r, c });
  return out;
}
export function cellSpan(layer: DesignLayer, r: number, c: number) {
  const m = mergeAt(layer, r, c);
  return m && m.r === r && m.c === c ? { rowspan: m.rowspan, colspan: m.colspan } : { rowspan: 1, colspan: 1 };
}
export function selectionBounds(cells: CellRef[]) {
  const rs = cells.map(cell => cell.r), cs = cells.map(cell => cell.c);
  return { r1: Math.min(...rs), c1: Math.min(...cs), r2: Math.max(...rs), c2: Math.max(...cs) };
}
export function cellsInRect(r1: number, c1: number, r2: number, c2: number): CellRef[] {
  const out: CellRef[] = [];
  for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) out.push({ r, c });
  return out;
}

/** Expand a selection to complete merged cells; never cut an existing merge in half. */
export function tableSelection(layer: DesignLayer, selected: CellRef[]) {
  const { rows, cols } = tableSize(layer);
  const valid = selected.filter(c => c.r >= 0 && c.c >= 0 && c.r < rows && c.c < cols);
  if (!valid.length) return { r1: 0, c1: 0, r2: rows - 1, c2: cols - 1 };
  const bounds = selectionBounds(valid);
  let expanded = true;
  while (expanded) {
    expanded = false;
    for (const m of layer.merges || []) {
      if (m.r <= bounds.r2 && m.r + m.rowspan > bounds.r1 && m.c <= bounds.c2 && m.c + m.colspan > bounds.c1) {
        const next = { r1: Math.min(bounds.r1, m.r), c1: Math.min(bounds.c1, m.c), r2: Math.max(bounds.r2, m.r + m.rowspan - 1), c2: Math.max(bounds.c2, m.c + m.colspan - 1) };
        if (JSON.stringify(next) !== JSON.stringify(bounds)) { Object.assign(bounds, next); expanded = true; }
      }
    }
  }
  return bounds;
}

export function mergeCells(layer: DesignLayer, selected: CellRef[]): Partial<DesignLayer> {
  if (selected.length < 2) return {};
  const { r1, c1, r2, c2 } = tableSelection(layer, selected);
  const { rows, cols } = tableSize(layer);
  const cells = Array.from({ length: rows * cols }, (_, i) => layer.cells?.[i] || "");
  const pieces: string[] = [];
  for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) {
    const value = cells[cellIndex(cols, r, c)];
    if (value && !isCovered(layer, r, c)) pieces.push(value);
    cells[cellIndex(cols, r, c)] = "";
  }
  cells[cellIndex(cols, r1, c1)] = pieces.join(" ").slice(0, 160);
  const merges = (layer.merges || []).filter(m => m.r + m.rowspan <= r1 || m.r > r2 || m.c + m.colspan <= c1 || m.c > c2);
  merges.push({ r: r1, c: c1, rowspan: r2 - r1 + 1, colspan: c2 - c1 + 1 });
  return { cells, merges };
}
export function splitCell(layer: DesignLayer, cell: CellRef): Partial<DesignLayer> {
  const m = mergeAt(layer, cell.r, cell.c);
  return m ? { merges: (layer.merges || []).filter(item => item !== m) } : {};
}
export function setCellText(layer: DesignLayer, r: number, c: number, text: string): Partial<DesignLayer> {
  const { rows, cols } = tableSize(layer);
  const origin = mergeAt(layer, r, c);
  const cells = Array.from({ length: rows * cols }, (_, i) => layer.cells?.[i] || "");
  cells[cellIndex(cols, origin?.r ?? r, origin?.c ?? c)] = text.slice(0, 160);
  return { cells };
}
export function clearTableCells(layer: DesignLayer, selected: CellRef[]): Partial<DesignLayer> {
  const { r1, c1, r2, c2 } = tableSelection(layer, selected), { rows, cols } = tableSize(layer);
  return { cells: Array.from({ length: rows * cols }, (_, i) => Math.floor(i / cols) >= r1 && Math.floor(i / cols) <= r2 && i % cols >= c1 && i % cols <= c2 ? "" : layer.cells?.[i] || "") };
}
export function cellAtLocal(layer: DesignLayer, xs: number[], ys: number[], x: number, y: number): CellRef | null {
  const { rows, cols } = tableSize(layer);
  if (x < 0 || y < 0 || x > layer.width || y > layer.height) return null;
  let c = cols - 1, r = rows - 1;
  for (let i = 0; i < cols; i++) if (x < xs[i + 1]) { c = i; break; }
  for (let i = 0; i < rows; i++) if (y < ys[i + 1]) { r = i; break; }
  const m = mergeAt(layer, r, c);
  return m ? { r: m.r, c: m.c } : { r, c };
}

export function defaultTableBorder(layer: DesignLayer): TableBorder {
  return { color: layer.lineColor || layer.fill, width: layer.lineWidth ?? 2, style: layer.tableLineStyle || "solid" };
}
export function tableCellFill(layer: DesignLayer, r: number, c: number) {
  return layer.cellFills?.[cellKey(r, c)] ?? (r === 0 ? layer.headerFill : undefined) ?? layer.cellFill ?? "transparent";
}
export function tableCellGradient(layer: DesignLayer, r: number, c: number) { return layer.cellGradients?.[cellKey(r, c)]; }
export function tableCellBackground(layer: DesignLayer, r: number, c: number) { const g = tableCellGradient(layer, r, c); return g ? gradientCss(g) : tableCellFill(layer, r, c); }
export function tableCellTextColor(layer: DesignLayer, r: number, c: number) { return layer.cellTextColors?.[cellKey(r, c)] ?? layer.fill; }
export function tableCellTextStyle(layer: DesignLayer, r: number, c: number): Required<CellTextStyle> {
  const { xs, ys } = tableTracks(layer), span = cellSpan(layer, r, c);
  const w = xs[c + span.colspan] - xs[c], h = ys[r + span.rowspan] - ys[r];
  return {
    fontSize: layer.fontSize || Math.max(8, Math.min(h * .46, w * .22)), fontFamily: layer.fontFamily || "Arial",
    fontWeight: layer.fontWeight || (r === 0 && layer.headerFill ? 700 : 400), italic: layer.italic || false,
    underline: layer.underline || false, strikethrough: layer.strikethrough || false,
    align: layer.align === "left" || layer.align === "right" ? layer.align : "center", verticalAlign: "middle", lineHeight: layer.lineHeight || 1.12,
    letterSpacing: layer.letterSpacing || 0, ...layer.cellTextStyles?.[cellKey(r, c)],
  };
}
export function applyTableTextStyle(layer: DesignLayer, selected: CellRef[], patch: CellTextStyle): Partial<DesignLayer> {
  const b = tableSelection(layer, selected), cellTextStyles = { ...layer.cellTextStyles }, updates = cellTextOverrides(patch);
  for (const cell of cellsInRect(b.r1, b.c1, b.r2, b.c2)) {
    const key = cellKey(cell.r, cell.c);
    cellTextStyles[key] = { ...cellTextStyles[key], ...updates };
  }
  return { cellTextStyles };
}

/** Apply solid/gradient paint to the chosen cells only, including whole merges. */
export function applyTablePaint(layer: DesignLayer, selected: CellRef[], patch: Partial<DesignLayer>): Partial<DesignLayer> {
  const b = tableSelection(layer, selected), cellFills = { ...layer.cellFills }, cellGradients = { ...layer.cellGradients };
  for (const cell of cellsInRect(b.r1, b.c1, b.r2, b.c2)) {
    const key = cellKey(cell.r, cell.c);
    if (patch.fill !== undefined || Object.hasOwn(patch, "fillAlpha")) cellFills[key] = hexWithAlpha(patch.fill ?? tableCellFill(layer, cell.r, cell.c), patch.fillAlpha ?? 1);
    if (Object.hasOwn(patch, "fillGradient")) {
      if (patch.fillGradient) cellGradients[key] = { ...patch.fillGradient, stops: patch.fillGradient.stops.map(s => ({ ...s })) };
      else delete cellGradients[key];
    }
  }
  return { cellFills, cellGradients };
}
export function applyTableTextColor(layer: DesignLayer, selected: CellRef[], color: string): Partial<DesignLayer> {
  if (!selected.length) return { fill: color, cellTextColors: {} };
  const b = tableSelection(layer, selected), cellTextColors = { ...layer.cellTextColors };
  for (const cell of cellsInRect(b.r1, b.c1, b.r2, b.c2)) cellTextColors[cellKey(cell.r, cell.c)] = color;
  return { cellTextColors };
}

/** Border overrides are shared edges, not separate strokes painted twice by neighbours. */
export function applyTableBorders(layer: DesignLayer, selected: CellRef[], target: BorderTarget, border: TableBorder): Partial<DesignLayer> {
  if (!selected.length && target === "all") return { lineColor: border.color, lineWidth: border.width, tableLineStyle: border.style, tableBorders: {} };
  const { r1, c1, r2, c2 } = tableSelection(layer, selected);
  const tableBorders = { ...(layer.tableBorders || {}) };
  for (let r = r1; r <= r2 + 1; r++) for (let c = c1; c <= c2; c++) {
    const outer = r === r1 || r === r2 + 1;
    if (target === "all" || (target === "outer" && outer) || ((target === "inner" || target === "horizontal") && !outer) || (target === "top" && r === r1) || (target === "bottom" && r === r2 + 1)) tableBorders[`h:${r}:${c}`] = { ...border };
  }
  for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2 + 1; c++) {
    const outer = c === c1 || c === c2 + 1;
    if (target === "all" || (target === "outer" && outer) || ((target === "inner" || target === "vertical") && !outer) || (target === "left" && c === c1) || (target === "right" && c === c2 + 1)) tableBorders[`v:${r}:${c}`] = { ...border };
  }
  return { tableBorders };
}
export function applyTableFill(layer: DesignLayer, selected: CellRef[], fill: string): Partial<DesignLayer> {
  if (!selected.length) return { cellFill: fill, headerFill: undefined, cellFills: {}, cellGradients: {} };
  return applyTablePaint(layer, selected, { fill, fillAlpha: 1, fillGradient: undefined });
}

export function tableBorderSegments(layer: DesignLayer, width = layer.width, height = layer.height) {
  const { rows, cols, xs, ys } = tableTracks(layer, width, height);
  const fallback = defaultTableBorder(layer);
  const result: { key: string; x1: number; y1: number; x2: number; y2: number; border: TableBorder }[] = [];
  const sameMerge = (a: CellRef, b: CellRef) => { const x = mergeAt(layer, a.r, a.c), y = mergeAt(layer, b.r, b.c); return !!x && x === y; };
  for (let r = 0; r <= rows; r++) for (let c = 0; c < cols; c++) {
    if (r > 0 && r < rows && sameMerge({ r: r - 1, c }, { r, c })) continue;
    const key = `h:${r}:${c}`;
    result.push({ key, x1: xs[c], y1: ys[r], x2: xs[c + 1], y2: ys[r], border: layer.tableBorders?.[key] || fallback });
  }
  for (let r = 0; r < rows; r++) for (let c = 0; c <= cols; c++) {
    if (c > 0 && c < cols && sameMerge({ r, c: c - 1 }, { r, c })) continue;
    const key = `v:${r}:${c}`;
    result.push({ key, x1: xs[c], y1: ys[r], x2: xs[c], y2: ys[r + 1], border: layer.tableBorders?.[key] || fallback });
  }
  return result;
}

/** Inserts/deletes a track while preserving cell values, merges and remaining cell styles. */
export function mutateTableTrack(layer: DesignLayer, axis: TableAxis, action: "insert" | "delete", position: number): Partial<DesignLayer> {
  const { rows, cols } = tableSize(layer), isRow = axis === "row", count = isRow ? rows : cols;
  const insert = action === "insert";
  if ((insert && count >= (isRow ? MAX_TABLE_ROWS : MAX_TABLE_COLS)) || (!insert && count <= 1)) return {};
  const index = clamp(Math.trunc(position), 0, insert ? count : count - 1);
  const nextRows = rows + (isRow ? (insert ? 1 : -1) : 0), nextCols = cols + (!isRow ? (insert ? 1 : -1) : 0);
  const map = (v: number) => insert ? (v >= index ? v + 1 : v) : v === index ? -1 : v > index ? v - 1 : v;
  const cells = Array.from({ length: nextRows * nextCols }, () => "");
  const cellFills: Record<string, string> = {};
  const cellGradients: Record<string, GradientFill> = {};
  const cellTextColors: Record<string, string> = {};
  const cellTextStyles: Record<string, CellTextStyle> = {};
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const nr = isRow ? map(r) : r, nc = isRow ? c : map(c);
    if (nr < 0 || nc < 0) continue;
    cells[nr * nextCols + nc] = layer.cells?.[r * cols + c] || "";
    const fill = layer.cellFills?.[cellKey(r, c)];
    if (fill !== undefined) cellFills[cellKey(nr, nc)] = fill;
    const gradient = layer.cellGradients?.[cellKey(r, c)], textColor = layer.cellTextColors?.[cellKey(r, c)];
    if (gradient) cellGradients[cellKey(nr, nc)] = gradient;
    if (textColor !== undefined) cellTextColors[cellKey(nr, nc)] = textColor;
    const style = layer.cellTextStyles?.[cellKey(r, c)];
    if (style) cellTextStyles[cellKey(nr, nc)] = { ...style };
  }
  const merges: Merge[] = [];
  for (const merge of layer.merges || []) {
    const start = isRow ? merge.r : merge.c, span = isRow ? merge.rowspan : merge.colspan;
    let nextStart = start, nextSpan = span;
    if (insert) { if (index <= start) nextStart++; else if (index < start + span) nextSpan++; }
    else if (index < start) nextStart--; else if (index < start + span) nextSpan--;
    if (nextSpan < 1) continue;
    const next = { ...merge, ...(isRow ? { r: nextStart, rowspan: nextSpan } : { c: nextStart, colspan: nextSpan }) };
    if (!insert && index === start) {
      cells[next.r * nextCols + next.c] = layer.cells?.[merge.r * cols + merge.c] || cells[next.r * nextCols + next.c];
      const fill = layer.cellFills?.[cellKey(merge.r, merge.c)];
      if (fill !== undefined) cellFills[cellKey(next.r, next.c)] = fill;
      const gradient = layer.cellGradients?.[cellKey(merge.r, merge.c)], textColor = layer.cellTextColors?.[cellKey(merge.r, merge.c)];
      if (gradient) cellGradients[cellKey(next.r, next.c)] = gradient;
      if (textColor !== undefined) cellTextColors[cellKey(next.r, next.c)] = textColor;
      const style = layer.cellTextStyles?.[cellKey(merge.r, merge.c)];
      if (style) cellTextStyles[cellKey(next.r, next.c)] = { ...style };
    }
    if (next.rowspan > 1 || next.colspan > 1) merges.push(next);
  }
  const tableBorders: Record<string, TableBorder> = {};
  for (const [key, border] of Object.entries(layer.tableBorders || {})) {
    const [kind, r, c] = key.split(":");
    let nr = Number(r), nc = Number(c);
    const v = isRow ? nr : nc, boundary = isRow ? kind === "h" : kind === "v";
    let mapped: number;
    if (insert) mapped = v >= index + (boundary ? 1 : 0) ? v + 1 : v;
    else { if ((!boundary && v === index) || (boundary && v === index + 1)) continue; mapped = v > index ? v - 1 : v; }
    if (isRow) nr = mapped; else nc = mapped;
    tableBorders[`${kind}:${nr}:${nc}`] = { ...border };
  }
  const extent = isRow ? layer.height : layer.width;
  const tracks = tableFractions(layer, axis).map(fr => fr * extent);
  if (insert) tracks.splice(index, 0, tracks[Math.min(index, tracks.length - 1)] || extent / count); else tracks.splice(index, 1);
  const total = Math.min(20000, Math.max(8, tracks.reduce((a, b) => a + b, 0)));
  return { rows: nextRows, cols: nextCols, cells, merges, cellFills, cellGradients, cellTextColors, cellTextStyles, tableBorders, ...(isRow ? { height: total, rowHeights: normaliseTracks(tracks) } : { width: total, colWidths: normaliseTracks(tracks) }) };
}

export function resizeTableStructure(layer: DesignLayer, requestedRows: number, requestedCols: number): Partial<DesignLayer> {
  const rows = clamp(Math.round(requestedRows), 1, MAX_TABLE_ROWS), cols = clamp(Math.round(requestedCols), 1, MAX_TABLE_COLS);
  let next = { ...layer };
  for (const axis of ["row", "column"] as TableAxis[]) {
    const desired = axis === "row" ? rows : cols;
    while ((axis === "row" ? tableSize(next).rows : tableSize(next).cols) !== desired) {
      const current = axis === "row" ? tableSize(next).rows : tableSize(next).cols;
      next = { ...next, ...mutateTableTrack(next, axis, current < desired ? "insert" : "delete", current < desired ? current : current - 1) };
    }
  }
  return { rows, cols, cells: next.cells, merges: next.merges, cellFills: next.cellFills, cellGradients: next.cellGradients, cellTextColors: next.cellTextColors, cellTextStyles: next.cellTextStyles, tableBorders: next.tableBorders, colWidths: tableFractions(next, "column"), rowHeights: tableFractions(next, "row") };
}

export function setTableTrackSize(layer: DesignLayer, selected: CellRef[], axis: TableAxis, pixels: number): Partial<DesignLayer> {
  const isRow = axis === "row", count = isRow ? tableSize(layer).rows : tableSize(layer).cols;
  const extent = isRow ? layer.height : layer.width;
  const tracks = tableFractions(layer, axis).map(fr => fr * extent);
  const size = clamp(pixels, 8, 10000);
  if (!selected.length) tracks.fill(size);
  else {
    const first = selected[0], span = cellSpan(layer, first.r, first.c);
    const index = isRow ? first.r : first.c, length = isRow ? span.rowspan : span.colspan;
    const subtotal = tracks.slice(index, index + length).reduce((a, b) => a + b, 0);
    for (let i = index; i < Math.min(count, index + length); i++) tracks[i] = Math.max(8, tracks[i] / subtotal * size);
  }
  const total = Math.min(20000, tracks.reduce((a, b) => a + b, 0));
  return isRow ? { height: total, rowHeights: normaliseTracks(tracks) } : { width: total, colWidths: normaliseTracks(tracks) };
}

/** Reject unbounded or out-of-grid appearance maps received by the save API. */
export function isTableAppearance(layer: DesignLayer) {
  const { rows, cols } = tableSize(layer);
  const record = (value: unknown) => !!value && typeof value === "object" && !Array.isArray(value);
  const style = (value: unknown) => ["none", "solid", "dashed", "dotted"].includes(value as string);
  if (layer.tableLineStyle !== undefined && !style(layer.tableLineStyle)) return false;
  if (layer.cellFills !== undefined) {
    if (!record(layer.cellFills) || Object.keys(layer.cellFills).length > rows * cols) return false;
    for (const [key, value] of Object.entries(layer.cellFills)) {
      if (!/^\d+:\d+$/.test(key) || !colour(value)) return false;
      const [r, c] = key.split(":").map(Number);
      if (r >= rows || c >= cols) return false;
    }
  }
  for (const [map, valid] of [[layer.cellGradients, isGradientFill], [layer.cellTextColors, colour], [layer.cellTextStyles, isCellTextStyle]] as [Record<string, unknown> | undefined, (value: unknown) => boolean][]) {
    if (map === undefined) continue;
    if (!record(map) || Object.keys(map).length > rows * cols) return false;
    for (const [key, value] of Object.entries(map)) {
      if (!/^\d+:\d+$/.test(key) || !valid(value)) return false;
      const [r, c] = key.split(":").map(Number);
      if (r >= rows || c >= cols) return false;
    }
  }
  if (layer.tableBorders !== undefined) {
    if (!record(layer.tableBorders) || Object.keys(layer.tableBorders).length > (rows + 1) * cols + (cols + 1) * rows) return false;
    for (const [key, border] of Object.entries(layer.tableBorders)) {
      if (!/^[hv]:\d+:\d+$/.test(key) || !record(border)) return false;
      const [kind, r, c] = key.split(":");
      if (Number(r) >= rows + (kind === "h" ? 1 : 0) || Number(c) >= cols + (kind === "v" ? 1 : 0)) return false;
      if (!colour(border.color) || !style(border.style) || !Number.isFinite(border.width) || border.width < 0 || border.width > 60) return false;
    }
  }
  return true;
}

export const MASKS = [
  { key: "none", name: "Rectangle" }, { key: "rounded", name: "Rounded" }, { key: "circle", name: "Circle" },
  { key: "heart", name: "Heart" }, { key: "star", name: "Star" }, { key: "diamond", name: "Diamond" },
  { key: "hexagon", name: "Hexagon" }, { key: "blob", name: "Blob" }, { key: "flower", name: "Flower" },
] as const;
