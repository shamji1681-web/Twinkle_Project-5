/**
 * Custom-font text → vector outlines.
 *
 * Embedding uploaded font files into a PDF is where desktop importers (CorelDRAW in
 * particular) choke: CID/TrueType font dictionaries written by web PDF libraries come
 * out as "The file is corrupted", and CFF-based OTF files are worse still. Instead,
 * the glyphs themselves are converted to <path> outlines with the real font shapes.
 *
 * The PDF then contains no font file at all for custom type — just vector curves — so
 * it imports cleanly everywhere while keeping the exact letterforms. Text in the
 * standard families (Arial → Helvetica, Georgia → Times, …) is left as real text,
 * since those map to base-14 PDF fonts and never need embedding.
 */
import { parse } from "opentype.js";
import type { Font } from "opentype.js";
import { customFonts } from "@/lib/fonts";
import { embeddableFontBase64, base64ToBytes } from "@/lib/woff";
import { familyOf, fontSizeOf, pdfStandardFamily } from "@/lib/vector-export";

const SVG_NS = "http://www.w3.org/2000/svg";

export interface FontBank {
  /** Parsed uploads, keyed by lower-case family name. */
  fonts: Map<string, Font>;
  /** Families with no usable font file — their layers fall back to high-res patches. */
  unsupported: Set<string>;
}

async function parseUpload(dataUrl: string): Promise<Font | null> {
  const base64 = await embeddableFontBase64(dataUrl);
  if (!base64) return null;
  try {
    const bytes = base64ToBytes(base64);
    return parse(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer);
  } catch { return null; }
}

/** Loads every uploaded font the artwork uses. */
export async function loadFontBank(families: string[]): Promise<FontBank> {
  const fonts = new Map<string, Font>();
  const unsupported = new Set<string>();
  await Promise.all(families.map(async family => {
    if (pdfStandardFamily(family)) return;
    const stored = customFonts().find(font => font.name.toLowerCase() === family.toLowerCase());
    const parsed = stored ? await parseUpload(stored.dataUrl) : null;
    if (parsed) fonts.set(family.toLowerCase(), parsed);
    else unsupported.add(family);
  }));
  return { fonts, unsupported };
}

export interface RunOutline { d: string; width: number }

/**
 * Outlines one text run. Full shaping is used when the font's GSUB/GPOS tables are
 * understood (matching the browser's kerning and ligatures); fonts that hit an
 * unsupported lookup fall back to glyph-by-glyph outlines, so no type is ever lost
 * to an image.
 */
export function runOutlines(font: Font, content: string, start: number, y: number, size: number): RunOutline {
  try {
    const width = font.getAdvanceWidth(content, size, { kerning: true });
    return { d: font.getPath(content, start, y, size, { kerning: true }).toPathData(3), width };
  } catch {
    const scale = size / (font.unitsPerEm || 1000);
    let cursor = start;
    let width = 0;
    const parts: string[] = [];
    for (const char of Array.from(content)) {
      const glyph = font.charToGlyph(char);
      if (char.trim()) parts.push(glyph.getPath(cursor, y, size).toPathData(3));
      cursor += glyph.advanceWidth * scale;
      width += glyph.advanceWidth * scale;
    }
    return { d: parts.join(" "), width };
  }
}

const isBold = (value: string | null) => {
  const raw = (value || "").toLowerCase();
  if (raw === "bold" || raw === "bolder") return true;
  const numeric = Number.parseFloat(raw);
  return Number.isFinite(numeric) ? numeric >= 600 : false;
};

/** Shear that slants a run around its own baseline origin, like a real italic cut. */
const italicSkew = (x: number, y: number) => `translate(${x} ${y}) skewX(-12) translate(${-x} ${-y})`;

/**
 * Replaces every text run set in an uploaded font with its glyph outlines. Runs the
 * font cannot provide (missing file, parse failure) are left untouched so the patch
 * planner can fall back to a high-resolution layer for them.
 */
export function outlineCustomFonts(root: SVGSVGElement, bank: FontBank) {
  if (!bank.fonts.size) return;
  for (const text of Array.from(root.querySelectorAll("text"))) {
    const font = bank.fonts.get(familyOf(text).toLowerCase());
    if (!font) continue;
    const tspans = Array.from(text.children).filter(child => child.tagName.toLowerCase() === "tspan");
    try {
      const group = document.createElementNS(SVG_NS, "g");
      ["transform", "opacity", "fill", "stroke", "stroke-width", "stroke-linejoin", "style"].forEach(attr => {
        const value = text.getAttribute(attr);
        if (value !== null) group.setAttribute(attr, value);
      });
      const runs = tspans.length ? tspans : [text];
      for (const run of runs) {
        const content = run.textContent ?? "";
        if (!content) continue;
        const size = fontSizeOf(run) || fontSizeOf(text);
        const x = Number.parseFloat(run.getAttribute("x") ?? text.getAttribute("x") ?? "");
        const y = Number.parseFloat(run.getAttribute("y") ?? text.getAttribute("y") ?? "");
        if (!size || !Number.isFinite(x) || !Number.isFinite(y)) throw new Error("unpositioned run");
        const anchor = run.getAttribute("text-anchor") || text.getAttribute("text-anchor");
        // Measure first so centred and right-aligned runs land exactly like the canvas.
        const measured = runOutlines(font, content, 0, y, size);
        const start = anchor === "middle" ? x - measured.width / 2 : anchor === "end" ? x - measured.width : x;
        const path = document.createElementNS(SVG_NS, "path");
        path.setAttribute("d", measured.width === 0 || start === 0
          ? measured.d
          : runOutlines(font, content, start, y, size).d);
        // Fill, stroke and opacity travel with the outline so gradients, transparency
        // and text strokes survive; only the font geometry is replaced.
        ["fill", "stroke", "stroke-width", "stroke-linejoin", "stroke-linecap", "opacity", "style"].forEach(attr => {
          const value = run.getAttribute(attr) ?? text.getAttribute(attr);
          if (value !== null) path.setAttribute(attr, value);
        });
        if (isBold(run.getAttribute("font-weight") ?? text.getAttribute("font-weight"))) {
          // Synthetic bold: the uploads ship a single cut, so thicken in vector with a
          // same-colour hairline stroke (paths cannot trip the text-outline detector).
          const fill = path.getAttribute("fill");
          if (!path.getAttribute("stroke") && fill && fill !== "none" && !fill.startsWith("url(")) {
            path.setAttribute("stroke", fill);
            path.setAttribute("stroke-width", String(Math.max(0.6, size * 0.05)));
            path.setAttribute("stroke-linejoin", "round");
            path.setAttribute("stroke-linecap", "round");
          }
        }
        const slanted = run.getAttribute("font-style") === "italic" || (!run.hasAttribute("font-style") && text.getAttribute("font-style") === "italic");
        if (slanted) path.setAttribute("transform", italicSkew(x, y));
        group.appendChild(path);
      }
      text.replaceWith(group);
    } catch { /* unmeasurable run: patched as a high-resolution layer instead */ }
  }
}
